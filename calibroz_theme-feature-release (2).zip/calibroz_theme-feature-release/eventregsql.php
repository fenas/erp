<?php
include 'connection.php';
$name = $_GET['username'];
// echo $name;
$Email = $_GET['email'];
$contact = $_GET['contactno'];
$location = $_GET['location'];
$swo = $_GET['swo'];
$wpt= $_GET['wpt'];
$event_id=$_GET['eventid'];

$sql="INSERT INTO `event_enquiry`(`event_id`,`username`, `email`, `Mobileno`, `location`, `swo`, `work_training`, `dated`) VALUES('$event_id','$name','$Email','$contact','$location','$swo','$wpt','".date('Y-m-d')."')";

$result=mysqli_query($conn,$sql);
if(mysqli_affected_rows($conn)>0)
{
          echo "ok";
}
else
{
   
        echo "failed";
}

?> 