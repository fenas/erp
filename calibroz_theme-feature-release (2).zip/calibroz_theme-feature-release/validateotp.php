<?php
$number=$_GET['number'];
$otp=rand(1000,9999);
$msg="Your OTP is ".$otp."";
  $apiKey = urlencode('ZSv/4c21FQM-KhiNeQdR9KfjDtqWqtTdPY0RJUwaOe');
  
  // Message details
  $numbers = $number;
  $sender = urlencode('TXTLCL');
  $message = $msg;
 
  // Prepare data for POST request
  $data = array('apikey' => $apiKey, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
 
  // Send the POST request with cURL
  $ch = curl_init('https://api.textlocal.in/send/');
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  $response = curl_exec($ch);
  curl_close($ch);
  echo $otp;
?>
