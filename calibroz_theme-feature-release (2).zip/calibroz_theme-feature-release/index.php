
  <?php
include 'connection.php';
// session_start();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Calibroz is a professional software training institute located in Kalamassery,Kochi.">
        <meta name="keywords" content="Internship,selenium, php, java, html, DevOps, react, ">
        <meta name="author" content="trendytheme.net">

        <title>Calibroz</title>

        <!--  favicon -->

        <link rel="shortcut icon" href="assets/images/logkv.jpg">
        <!--  apple-touch-icon -->
        <!-- <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet"> -->
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/images/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/images/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/images/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/images/ico/apple-touch-icon-57-precomposed.png">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
        <link href='https://fonts.googleapis.com/css?family=Roboto:400,300,300italic,400italic,500,700' rel='stylesheet' type='text/css'>
        <!-- Animate CSS -->
        <link href="assets/css/animate.css" rel="stylesheet">
        <!-- jvectormap CSS -->
        <link href="assets/css/jquery-jvectormap.css" rel="stylesheet">
        <!-- FontAwesome CSS -->
        <link href="assets/fonts/font-awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- magnific-popup -->
        <link href="assets/magnific-popup/magnific-popup.css" rel="stylesheet">
        <!-- owl.carousel -->
        <!-- <link href="assets/owl.carousel/assets/owl.carousel.css" rel="stylesheet"> -->
        <!-- <link href="assets/owl.carousel/assets/owl.theme.default.min.css" rel="stylesheet"> -->
        <!-- Bootstrap -->
        <link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Style CSS -->
        <link href="style.css" rel="stylesheet">
       
        


     

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
<script type="text/javascript">
var myValue;
        function myFunc() 
        {
            var isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
            var element = document.getElementById('text');
            if (isMobile) 
            {
               location.href='tel:7356353563';
            } 
            else
            {
                location.href='#contact';
            }
        }
        function myOtp()
        {
          
            var number2 = document.getElementById("number");
             if (!number2.checkValidity())
                   {
                    document.getElementById("demo2").innerHTML = "* Number required";
                   
                  }
                  else if (number2.value.length < 10)
                    {
                    document.getElementById("demo2").innerHTML = "* Invalid number";              
                    }
                   else 
                   {    
                    var xmlhttp = new XMLHttpRequest();
                      xmlhttp.open("GET", "validateotp.php?number="+number2.value);
                      xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                      xmlhttp.send();
                      xmlhttp.onreadystatechange = function() {
                        if (this.readyState === 4 && this.status === 200) {
                            
                          document.getElementById("demo2").innerHTML ="Please enter the OTP that send to your phone ";
                          myValue=this.responseText;
                        } else {
                          document.getElementById("demo2").innerHTML = "Something went wrong!! try again.";
                          myValue="";
                        };
                      }
                     
                   } 
        }
         function myFunction()
           {

                var inpObj = document.getElementById("name");
                var number = document.getElementById("number");
                var otp_number = document.getElementById("otp");
                var email = document.getElementById("email");
                var mobileno = document.getElementById("number");
                var message = document.getElementById("message");

                  if (!inpObj.checkValidity()) 
                  {
                    document.getElementById("demo").innerHTML ="* Name required";
                    
                  }
                 else if (!number.checkValidity())
                   {
                    document.getElementById("demo2").innerHTML = "* Number required";
                   
                  }
                  else if (number.value.length < 10)
                    {
                    document.getElementById("demo2").innerHTML = "* Invalid number";
                   
                    }
                     else if (!otp_number.checkValidity())
                    {
                    document.getElementById("demo3").innerHTML = "* Enter OTP";
                    }
                    else if(myValue != otp_number.value)
                    {
                       document.getElementById("demo3").innerHTML = "* Invalid OTP";
                    }
                   else 
                   {
                     document.getElementById("demo").innerHTML = "";
                     document.getElementById("demo2").innerHTML = "";
                     document.getElementById("demo3").innerHTML = "";
                     if(confirm( "Thank you!!. Your request added successfully" ))
                     {
                      var xmlhttp = new XMLHttpRequest();
                      xmlhttp.open("GET","enquiryform.php?number="+number.value+"&otp="+otp_number.value+"&email="+email.value+"&message="+message.value+"&name="+inpObj.value);
                      xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                      xmlhttp.send();
                      xmlhttp.onreadystatechange = function() 
                      {
                        if (this.readyState === 4 && this.status === 200)
                        {
                             location.reload(true);
                            
                                              
                        } 
                        else {
                         
                         // window.alert('failed!');
                        }
                      }
                     
                        
                     }
                    
                    }   
             



          }
      
        // function submitButton()
        //   {
        //    var username = document.getElementById("username");
        //    var email = document.getElementById("email");
        //    var eventid = document.getElementById("eventid");
        //    var contactno = document.getElementById("contactno");
        //    var location = document.getElementById("location");
        //    var swo = document.getElementById("swo");
        //    var wpt = document.getElementById("wpt");
        //    if (username.checkValidity() && email.checkValidity() && checkValidity())  
        //           {
        //             document.getElementById("demo").innerHTML ="* Name required";
                    
        //           }

        //    var xmlhttp = new XMLHttpRequest();
        //               xmlhttp.open("GET", "eventregsql.php?username="+username.value+"&email="+email.value+"&eventid="+eventid.value+"&contactno="+contactno.value+"&location="+location.value+"&swo="+swo.value+"&wpt="+wpt.value);
        //               xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        //               xmlhttp.send();
        //               xmlhttp.onreadystatechange = function() 
        //               {
        //                 if (this.readyState === 4 && this.status === 200)
        //                  {
        //                   window.alert(this.responseText);
                      
        //                 }
        //               } 
        //   }

          
          
</script>


<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-KJ9R6RP');</script>
<!-- End Google Tag Manager -->
    </head>

    <body id="page-top" data-spy="scroll" data-target=".navbar">


            <a href="javascript:" id="return-to-top"><i class="fa fa-arrow-up"></i></a>
            <a onClick="javascript:myFunc()" id="fab"><i class="fa fa-phone"></i> </a>
        

        <!-- top-bar -->
        <div id="topbar" class="top-bar">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-7">
                        <div class="cta-wrapper">
                            <ul class="list-inline">
                                  <li>
                                    <a href="https://mail.google.com/mail/?view=cm&fs=1&tf=1&to=happylearing@calibroz.com" target="_blank">
                                    <i class="fa fa-envelope">
                                    </i>
                                     happylearning@calibroz.com
                                   </a>
                                 </li>
                                <li>
                                  <a onClick="javascript:myFunc()">
                                    <i class="fa fa-phone">
                                    </i>
                                  +917356353563
                                </a>
                              </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-5">
                        <div class="social-wrapper text-right">
                            <ul class="list-inline">
                                <li><a href="https://www.facebook.com/cybercampus.calibroz/" target="_blank"><i class="fa fa-facebook"></i></a></li>
                                  <li><a href="https://twitter.com/PeopleOfficer" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/calibroz/?hl=en" target="_blank" ><i class="fa fa-instagram"></i></a></li>
                                <li><a href="https://in.linkedin.com/company/calibroz" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                                <!-- <li><a href="#"><i class="fa fa-tumblr"></i></a></li> -->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- top-bar end-->


        <!-- Navigation start -->
        <nav class="navbar navbar-custom" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#custom-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand " href="index.php">
                        <img src="assets/images/resizedlog.png" alt="logo" width="200px" height="40px">
                    <!-- <img src="http://cybercampus.calibroz.com/assets/images/calibroz.png width=18% height=30%"> -->
                    </a>
                </div>

                <div class="collapse navbar-collapse" id="custom-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active"><a class="page-scroll" href="#page-top">Home</a></li>
                        <li><a class="page-scroll" href="#pppp">About</a></li>
                        <li><a class="page-scroll" href="#course">Courses</a></li>
                        <!-- <li><a class="page-scroll" href="#work">Works</a></li> -->
                        <!-- <li><a class="page-scroll" href="#team">Team</a></li> -->
                        <li><a class="page-scroll" href="#blog">Events</a></li>
                        <li><a class="page-scroll" href="#portfolio">Gallery</a></li>

                        <li><a class="page-scroll" href="#contact">Contact</a></li>
                    </ul>
                </div>

            </div><!-- .container -->
        </nav>
        <!-- Navigation end -->



        <!-- Slider Section -->
        <section id="home" class="slider-section">
          <div id="tt-carousel" class="carousel tt-carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
              <li data-target="#tt-carousel" data-slide-to="0" class="active"></li>

              <li data-target="#tt-carousel" data-slide-to="1"></li>
            <li data-target="#tt-carousel" data-slide-to="2"></li>

            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner">
              <div class="item active">
                <div class="container">
                  <div class="row">
                    <div class="col-md-6 col-sm-7">
                        <div class="carousel-intro">
                          <h1 class="animated fadeInDown animation-delay-6 carousel-title slidetext"  >Software Training at</h1>

                          <h2 class="animated fadeInDown animation-delay-4 crousel-subtitle slidetext">Calibroz</h2>
 
                          <p class="animated fadeInUp animation-delay-10 slidetext">Calibroz is a professional software training institute located in Kalamassery, Kochi. We have been providing intense training for both students, teachers, and professionals for the last 2 years. Our management and trainers are having multiple years of industrial experience and are currently working in Cochin based MNCs.</p>
                          <a href="#contact" class=" btn btn-default animated fadeInUp animation-delay-10" >Contact Us</a> 
                          
                          <!-- <a href="#" class=" btn btn-default animated fadeInUp animation-delay-10" style="color: rgb(11, 96, 145)">Learn more</a>  -->
                        </div><!-- /.carousel-intro -->
                    </div><!-- /.col-md-6 -->

                    <div class="col-md-6 col-sm-5 ">
                      <div class="carousel-img layer-one">
                        <img src="assets/images/layer-1.png" class="img-responsive animated bounceInDown animation-delay-3" alt="sliderBackground">
                      </div><!-- /.carousel-img-->
                    </div><!-- /.col-md-6 -->
                  </div><!-- /.row -->
                </div><!-- /.container -->
              </div><!-- /.item -->

              <div class="item">
                <div class="container">
                  <div class="row">
                    <div class="col-md-6 col-sm-8">
                        <div class="carousel-intro">
                          <h1 class="animated fadeInDown animation-delay-6 carousel-title slidecolor">What we do at</h1>

                          <h2 class="animated fadeInDown animation-delay-4  crousel-subtitle slidecolor">Calibroz</h2>
 
                          <p class="animated fadeInUp animation-delay-10 slidecolor">
                           <p class="font animated fadeInUp animation-delay-10"> <i class="fa fa-circle"></i><span>&nbsp COURSES:</span> &nbsp We are offering 3 Months, 6 Months courses with live project experiences.<br>
                         <i class="fa fa-circle"></i><span>&nbsp INTERNSHIP:</span>&nbsp We bring you the oppurtunity to work on live projects with real time scenarios (3-6 Months).<br>
                        <i class="fa fa-circle"></i><span>&nbsp PROJECT SUPPORT.</span>&nbsp<br>
                          <i class="fa fa-circle"></i> &nbsp ON & OFF CAMPUS SESSIONS.</p><br>

                           <p class="font">for more details....</p>
                          <a href="#contact" class=" btn btn-default animated fadeInUp animation-delay-10" >Contact Us</a> 
                        </div><!-- /.carousel-intro -->
                    </div><!-- /.col-md-6 -->
 
                    <div class="col-md-6 col-sm-4 carousel-img-wrap">
                      <div class="carousel-img layer-two">
                        <img src="assets/images/girl-2.png" class="img-responsive animated bounceInDown animation-delay-3" alt="sliderBackground">
                      </div><!-- /.carousel-img-->
                    </div><!-- /.col-md-6 -->
                  </div><!-- /.row -->
                </div><!-- /.container -->
              </div><!-- /.item -->

<!-- 3rd slide item -->
              <div class="item">
                    <div class="container">
                      <div class="row">
                        <div class="col-md-6 col-sm-7">
                            <div class="carousel-intro">
                              <h1 class="animated fadeInDown animation-delay-6 carousel-title slidetext" >searching for leading</h1>
    
                              <h2 class="animated fadeInDown animation-delay-4 crousel-subtitle slidetext">software training institute?</h2>
     
                              <p class="animated fadeInUp animation-delay-10 slidetext">we are providing  training in selenium, php, java, html, DevOps, react, machinelearning, internet of things, cordova etc ... courses.For more details...</p>
                              <a href="#contact" class=" btn btn-default animated fadeInUp animation-delay-10" >Contact Us</a> 
                              
                              <!-- <a href="#" class=" btn btn-default animated fadeInUp animation-delay-10" style="color: rgb(11, 96, 145)">Learn more</a>  -->
                            </div><!-- /.carousel-intro -->
                        </div><!-- /.col-md-6 -->
    
                        <div  class="col-md-6 col-sm-5 ">
                          <div  class="carousel-img layer-one">
                            <img src="assets/images/penguin.png" class="img-responsive animated bounceInDown animation-delay-3" alt="sliderBackground">
                          </div><!-- /.carousel-img-->
                        </div><!-- /.col-md-6 -->
                      </div><!-- /.row -->
                    </div><!-- /.container -->
                  </div><!-- /.item -->
            </div><!-- /.carousel-inner -->
          </div>
        </section>
        <!-- Slider Section End -->

 <!-- About Section -->
 <div id="pppp" class="aboutsize"></div>

        <section  class="about-section section-padding gray-bg">


            <div  class="container">
                <div class="section-title">
                    <h2  >About<span class="light-text">&nbsp Calibroz</span></h2>
                    <div class="title-border-container">
                        <div class="title-border"></div>
                    </div>
                </div>

                <div class="row mt-30">

                    <div class="col-md-6">
                        <div class="post-desc">
                            <p class="mb-20">A group of passionate professionals with common values & believes, decided to share their cumulative knowledge & wisdom with others and that great notion lead to the birth of Calibroz Cyber Campus in the year 2016.</p>

                            <ul class=" clearfix mb-20">
                                <li class="mb-20">
                                    <h4 class="aboutcolor">Vision</h4>
                                    We as a team have been fortunate enough to learn from our experience, and our vision is to transfer this knowledge to the people around the world in a heuristic approach.
                                </li>

                                <li >
                                        <h4 class="aboutcolor">Mission</h4>
                                        We find out the caliber of each and help them to sharpen their skills, according to their convenience & interests.
                                </li>
                               
                            </ul>

                            <!-- <div>
                                <a href="#" class="btn btn-primary text-uppercase"> Details </a>
                            </div> -->
                        </div><!-- /.post-desc -->
                    </div><!-- /.col-md-6 -->

                    <div   class="col-md-6">
                        <div  class="post-img">
                            <img class="img-responsive" src="assets/images/mac1.png" alt="" width="400px" height="300px">
                        </div><!-- /.post-img -->
                    </div><!-- /.col-md-6 -->

                </div><!-- /.row -->
            </div ><!-- /.container -->
        </section>
        <!-- About Section End -->

        <!-- Service Section -->
        <section  class="service-section section-padding" >
             <div id="course" class="aboutsize"></div>
            <div class="container">
                <div class="section-title">
                    <h2>Our <span class="light-text">Courses</span></h2>
                    <div class="title-border-container">
                        <div class="title-border"></div>
                    </div>
                </div><!-- /.section-title -->

                 <div class="row mt-30">
                        <center><h1 class="coursesize">FUTURISTIC COURSES</h1></center>
                                      

                                                <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex7div">
                                                 
                                                        <div class="featured-item mb-30">
                                                            <div class="icon square">
                                                                <!-- <i class="fa fa-desktop"></i> -->
                                                             <i><img  class="icon" src="assets/images/devoops.jpg" alt=""> </i>

                                                            </div>
                                                            <div id="ex7" class="modal">
                                                                    <p>Due to the intensive work DevOps engineers and their teams complete on a daily basis, it's important to always be on the lookout for tools to improve efficiency and productivity. Unfortunately, there isn't enough time in the day to dig for top-rated DevOps tools that fit the team. We can help you with these latest tools </p>
                                                                     <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                            </div>
                                                            <div class="title">
                                                                <h3><p><a href="#ex7" rel="modal:open">DEVOPS </a></p></h3>
                                                            </div>
                                                        
                                                        </div><!-- /.featured-item -->
                                                    </div><!-- /.col-md-4 -->
                                             
  <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex8div">
                                                        <div class="featured-item mb-30">
                                                            <div class="icon square">
                                                                <!-- <i class="fa fa-desktop"></i> -->
                                                              <i><img class="icon" src="assets/images/ml.png" alt=""> </i>

                                                            </div>
                                                            <div id="ex8" class="modal">
                                                                    <p>Machine learning is the science of getting computers to act without being explicitly programmed. Machine learning is so pervasive today that you probably use it dozens of times a day without knowing it. Many researchers also think it is the best way to make progress towards human-level AI. In this class, you will learn about the most effective machine learning techniques, and gain practice implementing them and getting them to work for yourself </p>
                                                                      <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>                                                            </div>
                                                            <div class="title">
                                                                <h3><p><a href="#ex8" rel="modal:open">MACHINE LEARNING </a></p></h3>
                                                            </div>
                                                        
                                                        </div><!-- /.featured-item -->
                                                    </div><!-- /.col-md-4 -->
                                                 <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex9div">
                                                        <div class="featured-item mb-30">
                                                            <div class="icon square">
                                                                <!-- <i class="fa fa-desktop"></i> -->
                                                                <i><img class="icon" src="assets/images/iot.jpg" alt=""> </i>
                                                            </div>
                                                            <div id="ex9" class="modal">
                                                                    <p>Learn how to give life to devices over internet! This course will teach you the skills required to launch your career that is of great demand and build a smart environment.</p> 
                                                                    <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                            </div>
                                                            <div class="title">
                                                                <h3><p><a href="#ex9" rel="modal:open">INTERNET OF THINGS</a></p></h3>
                                                            </div>
                                                        
                                                        </div><!-- /.featured-item -->
                                                    </div><!-- /.col-md-4 -->
                                                     <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex17div">
                        <div class="featured-item mb-30">
                            <div class="icon square">
                                <!-- <i class="fa fa-desktop"></i> -->
                                 <i><img class="icon" src="assets/images/rpa.png" alt=""> </i>
                            </div>
                            <div id="ex17" class="modal">
                                    <p>RPA is economically efficient than any other automation solutions that exist currently. Implementing RPA for redundant business processes also enables human beings to shift their focus from repetitive tasks to tasks requiring emotional intelligence, reasoning, judgement and interactions with the customers.</p>
                                         <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                        <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                    </div>
                            <div class="title">
                                <h3><p><a href="#ex17" rel="modal:open">RPA </a></p></h3>
                            </div>
                        
                        </div><!-- /.featured-item -->
                    </div><!-- /.col-md-4 -->
                                          
                     


            </div><!-- /.container -->
 
                <div class="row mt-30">
                  <center><h1 class="coursesize">DEVELOPMENT</h1></center>
                     <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex1div">
                          <div class="featured-item mb-30">
                            <div class="icon square">
                                <!-- <i class="fa fa-desktop"></i> -->
                                <!-- <img src="assets/images/php.png"> -->
                    <i><img class="icon" src="assets/images/php.png" alt=""> </i>

                            </div>
                        
                  


                            <!-- Link to open the modal -->

                              <div id="ex1" class="modal">
                                 <p>PHP is a server side scripting language. that is used to develop Static websites or Dynamic websites or Web applications. PHP stands for Hypertext Pre-processor, that earlier stood for Personal Home Pages. PHP scripts can only be interpreted on a server that has PHP installed</p>
                                    <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                      <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                              </div>
                            <div class="title">
                                <h3><p><a href="#ex1" rel="modal:open">PHP</a></p></h3> 
                            </div>
                            <!-- <div class="desc">
                                <p>Authoritatively re-engineer enterprise data for cross-unit products. Energistically reintermediate seamless e-markets before granular.</p>
                            </div> -->
                        </div><!-- /.featured-item -->
                    </div><!-- /.col-md-4 -->
  <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex2div">
                        <div class="featured-item mb-30">
                            <div class="icon square">
                                <!-- <i class="fa fa-desktop"></i> -->
                        <i><img class="icon" src="assets/images/python.png" alt=""> </i>

                            </div>
                                <!-- Modal HTML embedded directly into document -->
                                <div id="ex2" class="modal">
                                <p>Python is a general purpose programming language. Hence, you can use the programming language for developing both desktop and web applications. Also, you can use Python for developing complex scientific and numeric applications. Python is designed with features to facilitate data analysis and visualization. </p>
                                                                     <a id="more_id" rel="modal:close" onclick="location.href = '#contact';"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>                                </div>

                            <div class="title">
                                <h3><p><a href="#ex2" rel="modal:open">PYTHON</a></p></h3>
                            </div>
                           <!--  <div class="desc">
                                <p>Authoritatively re-engineer enterprise data for cross-unit products. Energistically reintermediate seamless e-markets before granular.</p>
                            </div> -->
                        </div><!-- /.featured-item -->
                    </div><!-- /.col-md-4 -->


                      <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex3div">
                        <div class="featured-item mb-30">
                            <div class="icon square">
                                <!-- <i class="fa fa-desktop"></i> -->

                        <i><img class="icon" src="assets/images/.net.png" alt=""> </i>


                            </div>
                                <!-- Modal HTML embedded directly into document -->
                                <div id="ex3" class="modal">
                                <p>The ASP.NET MVC is a web application framework developed by Microsoft, which implements the model–view–controller pattern. This helps you to develop web applications with clean separation of concern (SoC) and it also enables Test Driven Development(TDD). </p>
                                        <a id="more_id" rel="modal:close" onclick="location.href = '#contact';"><b class="color">Click to Know More</b></a>
                                      <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                            </div>

                            <div class="title">
                                <h3><p><a href="#ex3" rel="modal:open">ASP.NET MVC</a></p></h3>
                            </div>
                          
                        </div><!-- /.featured-item -->
                    </div><!-- /.col-md-4 -->

                     <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex4div">
                        <div class="featured-item mb-30">
                            <div class="icon square">
                                <!-- <i class="fa fa-desktop"></i> -->
                            <i><img class="icon" src="assets/images/java.png" alt=""> </i>

                            </div>
                            <div id="ex4" class="modal">
                                    <p>Our unique course structure will help you to create java programs that are more advanced than you have already created or seen. In this course you will also learn the fundamentals of Object Oriented Programming, how to leverage the power of existing libraries, how to build graphical user interfaces, and how to use some core algorithms for searching and sorting data </p>
                                            <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                           <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                            </div>
                            <div class="title">
                                <h3><p><a href="#ex4" rel="modal:open">CORE JAVA </a></p></h3>
                            </div>
                        
                        </div><!-- /.featured-item -->
                    </div><!-- /.col-md-4 -->
                    


                      <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex5div">
                            <div class="featured-item mb-30">
                                <div class="icon square">
                                    <!-- <i class="fa fa-desktop"></i> -->
                                 <i><img class="icon" src="assets/images/adcjava.png" alt=""> </i>

                                </div>
                                <div id="ex5" class="modal">
                                        <p>Take your java programming skills into next level. Advanced Java is considered to be a concept that makes use of core java which is used in different real world applications. It is used by the client for creating or running applications. Java counts to be an object-oriented programming language which is intended for serving as a new option for the management of software complexity. </p>
                                               <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                               <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                </div>
                                <div class="title">
                                    <h3><p><a href="#ex5" rel="modal:open">ADVANCED JAVA</a></p></h3>
                                </div>
                            
                            </div><!-- /.featured-item -->
                        </div><!-- /.col-md-4 -->



                         <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex6div">
                                <div class="featured-item mb-30">
                                    <div class="icon square">
                                        <!-- <i class="fa fa-desktop"></i> -->
                                    <i><img class="icon" src="assets/images/j2ee.png" alt=""> </i>

                                    </div>
                                    <div id="ex6" class="modal">
                                            <p>J2EE is a platform-independent, Java-centric environment from Sun for developing, building and deploying Web-based enterprise applications online. The J2EE platform consists of a set of services, APIs, and protocols that provide the functionality for developing multi tiered, Web-based applications.</p> 
                                                       
                                               <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                  <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                    </div>
                                    <div class="title">
                                        <h3><p><a href="#ex6" rel="modal:open">J2EE</a></p></h3>
                                    </div>
                                
                                </div><!-- /.featured-item -->
                            </div><!-- /.col-md-4 -->


                      <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex12div">
                        <div class="featured-item mb-30">
                            <div class="icon square">
                                <!-- <i class="fa fa-desktop"></i> -->
                             <i><img class="icon" src="assets/images/django.png" alt=""> </i>
                            </div>
                            <div id="ex12" class="modal">
                                    <p>Django is an open-source python web framework used for rapid development, pragmatic, maintainable, clean design, and secures websites.. </p>
                                            <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                           <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                    </div>
                            <div class="title">
                                <h3><p><a href="#ex12" rel="modal:open">DJANGO</a></p></h3>
                            </div>
                        
                        </div><!-- /.featured-item -->
                    </div><!-- /.col-md-4 -->
                   <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex13div">
                        <div class="featured-item mb-30">
                            <div class="icon square">
                                <!-- <i class="fa fa-desktop"></i> -->
                                 <i><img class="icon" src="assets/images/spring.png" alt=""> </i>
                            </div>
                            <div id="ex13" class="modal">
                                    <p>Spring is a powerful, lightweight framework used for application development. In broader terms, you can say that the Spring framework is a well-defined tool that supports several web applications using Java as a programming language. </p>
                                           <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                          <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                    </div>
                            <div class="title">
                                <h3><p><a href="#ex13" rel="modal:open">SPRING </a></p></h3>
                            </div>
                        
                        </div><!-- /.featured-item -->
                    </div><!-- /.col-md-4 -->

                    <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex14div">
                        <div class="featured-item mb-30">
                            <div class="icon square">
                                <!-- <i class="fa fa-desktop"></i> -->
                                 <i><img class="icon" src="assets/images/hibernate.png" alt=""> </i>
                            </div>
                            <div id="ex14" class="modal">
                                    <p>Hibernate reduces lines of code by maintaining object-table mapping itself and returns result to application in form of Java objects. It relieves programmer from manual handling of persistent data, hence reducing the development time and maintenance cost.</p> 
                                   <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                  <!-- <a href="#contact" rel="modal:close"  ><b class="color">Click to Know More</b></a> -->

                                    <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>


                                    </div>
                            <div class="title">
                                <h3><p><a href="#ex14" rel="modal:open">HIBERNATE </a></p></h3>
                            </div>
                        
                        </div><!-- /.featured-item -->
                    </div><!-- /.col-md-4 -->


                        <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex16div">
                                <div class="featured-item mb-30">
                                    <div class="icon square">
                                        <!-- <i class="fa fa-desktop"></i> -->
                                    <i><img class="icon" src="assets/images/oracle.png" alt=""> </i>
                                    </div>
                                    <div id="ex15" class="modal">
                                            <p>
                                             Hyperion Workspace (Workspace) software is a modular business intelligence platform, which provides management reporting, query, and analysis capabilities for a wide variety of data sources in a single coordinated environment. </p>
                                                    <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                  <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                    </div>
                                    <div class="title">
                                        <h3><p><a href="#ex15" rel="modal:open">ORACLE HYPERION</a></p></h3>
                                    </div>
                                
                                </div><!-- /.featured-item -->
                            </div>

                                               
                                                



                </div><!-- .................end of row............. -->
                <div class="row mt-30">
                        <center><h1 class="coursesize">TESTING</h1></center>
                        <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex16div">
                              <div class="featured-item mb-30">
                                <div class="icon square">
                                    <!-- <i class="fa fa-desktop"></i> -->
                                  <i><img class="icon" src="assets/images/selenium.png" alt=""> </i>
                                </div>
                            
                                <!-- Modal HTML embedded directly into document -->
                                    <div id="ex16" class="modal">
                                    <p>Selenium Remote Control, also known as Selenium 1, which is the first Selenium tool that allowed users to use programming languages in creating complex tests.</p>
                                          <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                          <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>                                    </div>
    
                                <!-- Link to open the modal -->
                                <div class="title">
                                    <h3><p><a href="#ex16" rel="modal:open">SELENIUM</a></p></h3> 
                                </div>
                                <!-- <div class="desc">
                                    <p>Authoritatively re-engineer enterprise data for cross-unit products. Energistically reintermediate seamless e-markets before granular.</p>
                                </div> -->
                            </div><!-- /.featured-item -->
                        </div><!-- /.col-md-4 -->

                    
    
                        <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex18div">
                            <div class="featured-item mb-30">
                                <div class="icon square">
                                    <!-- <i class="fa fa-desktop"></i> -->
                                    <i><img class="icon" src="assets/images/cucumber.jpg" alt=""> </i>
                                </div>
                                    <!-- Modal HTML embedded directly into document -->
                                    <div id="ex18" class="modal">
                                    <p>Cucumber makes your team amazing. At a glance, Cucumber might just look like another tool for running automated tests. But it's more than that. A single source of truth. Cucumber merges specification and test documentation into one cohesive whole. Living documentation. We can help you excel in this tool. </p>
                                           <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                          <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>                                    </div>
    
                                <div class="title">
                                    <h3><p><a href="#ex18" rel="modal:open">CUCUMBER</a></p></h3>
                                </div>
                               <!--  <div class="desc">
                                    <p>Authoritatively re-engineer enterprise data for cross-unit products. Energistically reintermediate seamless e-markets before granular.</p>
                                </div> -->
                            </div><!-- /.featured-item -->
                        </div><!-- /.col-md-4 -->
    
                        <!--  -->
    
                       <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex19div">
                            <div class="featured-item mb-30">
                                <div class="icon square">
                                    <!-- <i class="fa fa-desktop"></i> -->
                                    <i><img class="icon" src="assets/images/readyapi.png" alt=""> </i>
                                </div>
                                <div id="ex19" class="modal">
                                        <p>
                                        In ReadyAPI, you can easily manage your projects and APIs. You can manage WSS configurations, authorization profiles, and define different environments that will be used across your functional, load and secure tests and in virtualized services (virts). You can easily create an API from an OpenAPI, Swagger, WSDL or WADL definition, or use Discovery to record API requests and methods.</p> 
                                              <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                              <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                </div>
                                <div class="title">
                                    <h3><p><a href="#ex19" rel="modal:open">READYAPI </a></p></h3>
                                </div>
                               
                            </div><!-- /.featured-item -->
                        </div><!-- /.col-md-4 -->

                        <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex20div">
                                <div class="featured-item mb-30">
                                    <div class="icon square">
                                        <!-- <i class="fab fa-php"></i> -->
                                    <i><img class="icon" src="assets/images/appium.jpg" alt=""> </i>
                                    </div>
                                    <div id="ex20" class="modal">
                                            <p>Appium drives GUI-related widgets and controls, allowing the same scripts to run for different software versions of various apps.</p>
                                                    <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                  <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                    </div>
                                    <div class="title">
                                        <h3><p><a href="#ex20" rel="modal:open">APPIUM </a></p></h3>
                                    </div>
                                
                                </div><!-- /.featured-item -->
                            </div><!-- /.col-md-4 -->
                            
                        <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex21div">
                                <div class="featured-item mb-30">
                                    <div class="icon square">
                                    <i><img class="icon" src="assets/images/manualtesting.png" alt=""> </i>
                                    </div>
                                    <div id="ex21" class="modal">
                                            <p>Automated testing helps you to find more bugs compare to a human tester. Manual testing is a less reliable testing method because it's conducted by a human .</p>
                                                <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                  <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                    </div>
                                    <div class="title">
                                        <h3><p><a href="#ex21" rel="modal:open">MANUAL TESTING </a></p></h3>
                                    </div>
                                
                                </div><!-- /.featured-item -->
                            </div><!-- /.col-md-4 -->
                       

                      

                            <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex22div">
                                    <div class="featured-item mb-30">
                                        <div class="icon square">
                                            <!-- <i class="fa fa-desktop"></i> -->
                                        <i><img class="icon" src="assets/images/soupui.png" alt=""> </i>

                                        </div>
                                        <div id="ex22" class="modal">
                                                <p>SoapUI is an open-source testing tool which can operate in cross-platforms. It is mainly used to test Web services and Web APIs.</p>
                                                   <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                      <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                        </div>
                                        <div class="title">
                                            <h3><p><a href="#ex22" rel="modal:open">SOUP UI</a></p></h3>
                                        </div>
                                    
                                    </div><!-- /.featured-item -->
                                </div><!-- /.col-md-4 -->






                        </div>

                       <div class="row mt-30">
                        <center><h1 class="coursesize">UI/UX</h1></center>
                        <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex23div">
                                                        <div class="featured-item mb-30">
                                                            <div class="icon square">
                                                                <!-- <i class="fa fa-desktop"></i> -->
                                                             <i><img class="icon" src="assets/images/html.jpg" alt=""> </i>
                                                            </div>
                                                            <div id="ex23" class="modal">
                                                                    <p>Creating a web site is no longer a tough task.In this course you will learn about the ways in which you can easily create web pages .</p> 
                                                                   
                                                                      <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                            </div>
                                                            <div class="title">
                                                                <h3><p><a href="#ex23" rel="modal:open">HTML </a></p></h3>
                                                            </div>
                                                        
                                                        </div><!-- /.featured-item -->
                                                    </div><!-- /.col-md-4 -->
                                                
                       
                                                 <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex.24div">
                                                        <div class="featured-item mb-30">
                                                            <div class="icon square">
                                                                <!-- <i class="fa fa-desktop"></i> -->
                                                           <i><img class="icon" src="assets/images/css.png" alt=""> </i>

                                                            </div>
                                                            <div id="ex24" class="modal">
                                                                    <p>In this course we'll ensure that you have a complete knowledge about the ways in which you can design the presentation of the web page.</p>  
                                                                        <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                            </div>
                                                            <div class="title">
                                                                <h3><p><a href="#ex24" rel="modal:open">CSS </a></p></h3>
                                                            </div>
                                                        
                                                        </div><!-- /.featured-item -->
                                                    </div><!-- /.col-md-4 -->

                                              
                                               <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex10div">
                                                        <div class="featured-item mb-30">
                                                            <div class="icon square">
                                                                <!-- <i class="fa fa-desktop"></i> -->
                                                               <i><img class="icon" src="assets/images/js.png" alt=""> </i>

                                                            </div>
                                                            <div id="ex10" class="modal">
                                                                    <p>You can create dynamic webpages , which are more interactive and attractive using JS. Our expert trainers will help you achieve this with our unique way of teaching methods.</p> 
                                                                           <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                            </div>
                                                            <div class="title">
                                                                <h3><p><a href="#ex10" rel="modal:open">JAVA SCRIPT</a></p></h3>
                                                            </div>
                                                        
                                                        </div><!-- /.featured-item -->
                                                    </div><!-- /.col-md-4 -->

                                                   <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex11div">
                                                        <div class="featured-item mb-30">
                                                            <div class="icon square">
                                                                <!-- <i class="fa fa-desktop"></i> -->
                                                                <i><img class="icon" src="assets/images/angular.png" alt=""> </i>
                                                            </div>
                                                            <div id="ex11" class="modal">
                                                                    <p>It is always better to be updated with the latest. Once you are through JS its time for Angular JS . AngularJS is a JavaScript-based open-source front-end web application framework .It allows your application to have expanded HTML library and much more features along with it.</p> 
                                                                         <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                            </div>
                                                            <div class="title">
                                                                <h3><p><a href="#ex11" rel="modal:open">ANGULAR </a></p></h3>
                                                            </div>
                                                        
                                                        </div><!-- /.featured-item -->
                                                    </div><!-- /.col-md-4 -->
                       
                                               <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex25div">
                                                        <div class="featured-item mb-30">
                                                            <div class="icon square">
                                                                <!-- <i class="fa fa-desktop"></i> -->
                                                                <i><img class="icon" src="assets/images/bootstrap.png" alt=""> </i>
                                                            </div>
                                                            <div id="ex25" class="modal">
                                                                    <p>Bootstrap is a free and open-source front-end web framework for designing websites and web applications. It helps you to built responsive web pages. </p>
                                                                           <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                            </div>
                                                            <div class="title">
                                                                <h3><p><a href="#ex25" rel="modal:open">BOOTSTRAP </a></p></h3>
                                                            </div>
                                                        
                                                        </div><!-- /.featured-item -->
                                                    </div><!-- /.col-md-4 -->
                            
                                                  <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex26div">
                                                        <div class="featured-item mb-30">
                                                            <div class="icon square">
                                                                <!-- <i class="fa fa-desktop"></i> -->
                                                                 <i><img class="icon" src="assets/images/ajax.png" alt=""> </i>
                                                            </div>
                                                            <div id="ex26" class="modal">
                                                                    <p>Ajax is a set of Web development techniques using many Web technologies on the client side to create asynchronous Web applications. </p>
                                                                            <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                            </div>
                                                            <div class="title">
                                                                <h3><p><a href="#ex26" rel="modal:open">AJAX </a></p></h3>
                                                            </div>
                                                        
                                                        </div><!-- /.featured-item -->
                                                    </div><!-- /.col-md-4 -->
                       

                      

                                               <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex27div">
                                                        <div class="featured-item mb-30">
                                                            <div class="icon square">
                                                                <!-- <i class="fa fa-desktop"></i> -->
                                                                <i><img class="icon" src="assets/images/jq.jpg" alt=""> </i>
                                                            </div>
                                                            <div id="ex27" class="modal">
                                                                    <p>jQuery is a cross-platform JavaScript library designed to simplify the client-side scripting of HTML. The purpose of jQuery is to make it much easier to use JavaScript on your website. </p>
                                                                             <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                            </div>
                                                            <div class="title">
                                                                <h3><p><a href="#ex27" rel="modal:open">JQUERY </a></p></h3>
                                                            </div>
                                                        
                                                        </div><!-- /.featured-item -->
                                                    </div><!-- /.col-md-4 -->
                                       </div>

                                             <div class="row mt-30">
                                                <center><h1 class="coursesize">REPORTING TOOL</h1></center>
                                                 <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex28div">
                                                      <div class="featured-item mb-30">
                                                      <div class="icon square">
                                                        <!-- <i class="fa fa-desktop"></i> -->
                                                       <i><img class="icon" src="assets/images/jasper.png" alt=""> </i>
                                                       </div>
                                              <div id="ex28" class="modal">
                                               <p>Jasper is an open source Java reporting tool that can write to a variety of targets, such as: screen, a printer, into PDF, HTML, Microsoft Excel, RTF, ODT .</p>
                                                       <a id="more_id" rel="modal:close" onclick="location.href = '#contact';"><b class="color">Click to Know More</b></a>
                                                       <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                              </div>
                                              <div class="title">
                                              <h3><p><a href="#ex28" rel="modal:open">JASPER </a></p></h3>
                                               </div>
                        
                                               </div><!-- /.featured-item -->
                                              </div><!-- /.col-md-4 -->


                                         <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex29div">
                                            <div class="featured-item mb-30">
                                                <div class="icon square">
                                                    <!-- <i class="fa fa-desktop"></i> -->
                                                 <i><img class="icon" src="assets/images/ms.png" alt=""> </i>

                                                </div>
                                                <div id="ex29" class="modal">
                                                        <p>In this course you will be able to learn all excel functionalities like calculation, graphic tools, pivot tables. </p>
                                                          <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                              <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                </div>
                                                <div class="title">
                                                    <h3><p><a href="#ex29" rel="modal:open">MICROSOFT EXCEL</a></p></h3>
                                                </div>
                                            
                                            </div><!-- /.featured-item -->
                                        </div><!-- /.col-md-4 -->

                                        <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex30div">
                                            <div class="featured-item mb-30">
                                                <div class="icon square">
                                                    <!-- <i class="fa fa-desktop"></i> -->
                                                 <i><img class="icon" src="assets/images/crystel.jpg" alt=""> </i>

                                                </div>
                                                <div id="ex30" class="modal">
                                                        <p>Crystal Reports is a business intelligence application used to create custom reports from a variety of data sources. The package includes the major features needed for a business to create a database reporting environment.</p>
                                                                <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                </div>
                                                <div class="title">
                                                    <h3><p><a href="#ex30" rel="modal:open">CRYSTEL REPORTS</a></p></h3>
                                                </div>
                                            
                                            </div><!-- /.featured-item -->
                                        </div><!-- /.col-md-4 -->

                                        <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex31div">
                                            <div class="featured-item mb-30">
                                                <div class="icon square">
                                                    <!-- <i class="fa fa-desktop"></i> -->
                                                   <i><img class="icon" src="assets/images/birt.png" alt=""> </i>

                                                </div>
                                                <div id="ex31" class="modal">
                                                        <p>BIRT is an open source software project that provides the BIRT technology platform to create data visualizations and reports that can be embedded into rich client and web applications, especially those based on Java and Java EE.</p>
                                                               <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                </div>
                                                <div class="title">
                                                    <h3><p><a href="#ex31" rel="modal:open">BIRT</a></p></h3>
                                                </div>
                                            
                                            </div><!-- /.featured-item -->
                                        </div><!-- /.col-md-4 -->



                                </div>


                        <div class="row mt-30">
                        <center><h1 class="coursesize">DATA VISUALIZATION TOOLS</h1></center>
                      
                        <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex32div">
                                                <div class="featured-item mb-30">
                                                    <div class="icon square">
                                                        <!-- <i class="fa fa-desktop"></i> -->
                                                      <i><img class="icon" src="assets/images/tablu.jpg" alt=""> </i>

                                                    </div>
                                                    <div id="ex32" class="modal">
                                                            <p>Tableau is intended for newcomers to data visualization with no prior experience. We leverage Tableau's library of resources to demonstrate best practices for data visualization and data storytelling. By the end of this specialization, you will be able to generate powerful reports and dashboards that will help people make decisions and take action based on their business data. </p>
                                                                     <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                    </div>
                                                    <div class="title">
                                                        <h3><p><a href="#ex32" rel="modal:open">TABLEAU </a></p></h3>
                                                    </div>
                                                
                                                </div><!-- /.featured-item -->
                                            </div><!-- /.col-md-4 -->



                                            <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex33div">
                                                    <div class="featured-item mb-30">
                                                        <div class="icon square">
                                                            <!-- <i class="fa fa-desktop"></i> -->
                                                         <i><img class="icon" src="assets/images/bi.jpg" alt=""> </i>

                                                        </div>
                                                        <div id="ex33" class="modal">
                                                                <p>Microsoft Power BI works by connecting data sources and providing a dashboard of business intelligence to the users.  </p>
                                                                    <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                        </div>
                                                        <div class="title">
                                                            <h3><p><a href="#ex33" rel="modal:open">MICROSOFT POWER BI</a></p></h3>
                                                        </div>
                                                    
                                                    </div><!-- /.featured-item -->
                                                </div><!-- /.col-md-4 -->



                                                </div>



                      <div class="row mt-30">
                        <center><h1 class="coursesize">MOBILITY</h1></center>
                      
                         <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex34div">
                        <div class="featured-item mb-30">
                            <div class="icon square">
                                <!-- <i class="fa fa-desktop"></i> -->
                            <i><img class="icon" src="assets/images/react.png" alt=""> </i>
                            </div>
                            <div id="ex34" class="modal">
                                    <p>ReactJS basically is an open-source JavaScript library which is used for building user interfaces specifically for single page applications. It's used for handling view layer for web and mobile apps. </p>
                                           <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                           <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                    </div>
                            <div class="title">
                                <h3><p><a href="#ex34" rel="modal:open">REACT </a></p></h3>
                            </div>
                        
                        </div><!-- /.featured-item -->
                    </div><!-- /.col-md-4 -->

                                      <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex35div">
                                        <div class="featured-item mb-30">
                                            <div class="icon square">
                                                <!-- <i class="fa fa-desktop"></i> -->
                                             <i><img class="icon" src="assets/images/ionic.png" alt=""> </i>

                                            </div>
                                            <div id="ex35" class="modal">
                                                    <p>One with skills in web technologies can easily create an app using Ionic. All you need is a little fine tuning of these skills. In this course you will learn to use AngularJS and the Ionic Framework to build robust, silky smooth hybrid mobile apps. </p>
                                                            <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                          <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                            </div>
                                            <div class="title">
                                                <h3><p><a href="#ex35" rel="modal:open">IONIC </a></p></h3>
                                            </div>
                                        
                                        </div><!-- /.featured-item -->
                                    </div><!-- /.col-md-4 -->

                                       <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex36div">
                                            <div class="featured-item mb-30">
                                                <div class="icon square">
                                                    <!-- <i class="fa fa-desktop"></i> -->
                                                <i><img class="icon" src="assets/images/cordova.png" alt=""> </i>

                                                </div>
                                                <div id="ex36" class="modal">
                                                        <p>Cordova command-line runs on Node.js and is available on NPM. Follow platform specific guides to install additional platform dependencies</p>
                                                         <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                              <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                </div>
                                                <div class="title">
                                                    <h3><p><a href="#ex36" rel="modal:open">CORDOVA</a></p></h3>
                                                </div>
                                            
                                            </div><!-- /.featured-item -->
                                        </div><!-- /.col-md-4 -->


                                <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex37div">
                                    <div class="featured-item mb-30">
                                        <div class="icon square">
                                            <!-- <i class="fa fa-desktop"></i> -->
                                            <i><img class="icon" src="assets/images/android.png" alt=""> </i>
                                        </div>
                                        <div id="ex37" class="modal">
                                                <p>In this course you will be able learn and create android apps more efficiently with ease. An Android application is defined using one or more of Android's four core application components. You will be able clearly understand the usage of Classes, interfaces & packages. </p>
                                                     <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                    <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>                                        </div>
                                        <div class="title">
                                            <h3><p><a href="#ex37" rel="modal:open">ANDROID</a></p></h3>
                                        </div>
                                    
                                    </div><!-- /.featured-item -->
                                </div><!-- /.col-md-4 -->


                                    <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex38div">
                                            <div class="featured-item mb-30">
                                                <div class="icon square">
                                                    <!-- <i class="fa fa-desktop"></i> -->
                                                 <i><img class="icon" src="assets/images/ios.png" alt=""> </i>

                                                </div>
                                                <div id="ex38" class="modal">
                                                        <p>iOS (formerly iPhone OS) is a mobile operating system created and developed by Apple Inc. exclusively for its hardware. It is the operating system that presently powers many of the company's mobile devices, including the iPhone, iPad, and iPod Touch.</p>
                                                              <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                <!-- <a  href="#contact"><b class="color">Click to Know More</b></a> -->
                                                                <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                </div>
                                                <div class="title">
                                                    <h3><p><a href="#ex38" rel="modal:open">IOS</a></p></h3>
                                                </div>
                                            
                                            </div><!-- /.featured-item -->
                                        </div><!-- /.col-md-4 -->

                </div>
              
                <!--promo theme color box end-->
                        <div class="row mt-30">
                        <center><h1 class="coursesize">DATA MINING</h1></center>
                          
                                                  <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex39div">
                                                        <div class="featured-item mb-30">
                                                            <div class="icon square">
                                                                <!-- <i class="fa fa-desktop"></i> -->
                                                            <i><img class="icon" src="assets/images/spark.png" alt=""> </i>
                                                             </div>
                                                            <div id="ex39" class="modal">
                                                                    <p>Apache Spark is open source, general-purpose distributed computing engine used for processing and analyzing a large amount of data.. </p>
                                                                    <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                            </div>
                                                            <div class="title">
                                                                <h3><p><a href="#ex39" rel="modal:open">APACHE SPARK </a></p></h3>
                                                            </div>
                                                        
                                                        </div><!-- /.featured-item -->
                                                    </div><!-- /.col-md-4 -->
                                                   <div onclick="coursesCardClicked(this.id)" class="col-md-4 serviceBoxShadow" id="ex40div">
                                                        <div class="featured-item mb-30">
                                                            <div class="icon square">
                                                                <!-- <i class="fa fa-desktop"></i> -->
                                                             <i><img class="icon" src="assets/images/hadoop.png" alt=""> </i>

                                                            </div>
                                                            <div id="ex40" class="modal">
                                                                    <p>The Apache Hadoop software library is a framework that allows for the distributed processing of large data sets across clusters of computers using simple programming models. It is designed to scale up from single servers to thousands of machines, each offering local computation and storage. </p>
                                                                 
                                                                             <a id="more_id" rel="modal:close" onClick="javascript:myFunc()"><b class="color">Click to Know More</b></a>
                                                                     <a href="#" rel="modal:close" class="pull-right" ><b class="color">Close</b></a>
                                                            </div>
                                                            <div  class="title">
                                                                <h3><p><a href="#ex40" rel="modal:open">APACHE HADOOP </a></p></h3>
                                                            </div>
                                                        
                                                        </div><!-- /.featured-item -->
                                                    </div><!-- /.col-md-4 -->
                                    </div><!-- /.container -->
                                </section>
                   <div id="blog" class="aboutsize"></div>             
  
        <section  class="news-section section-padding">
            <div id="blog" class="container">
                <div class="section-title">
                    <h2>Latest <span class="light-text">Events</span></h2>
                    <div class="title-border-container">
                        <div class="title-border"></div>
                    </div>
                 </div>


                  <div class="mt-30 col-md-6">
                          <div class="subscribe-wrapper text-center pull-right blue-color">
                            <h3>Get a news letter</h3>
                            <p><b>Get all latest updates and course details straight to your inbox, Subscribe NOW..</b></p>

                            <form class="" for="subscribeEmail" action="newstosql.php" role="form" method="POST">
                    
                                <!-- to showing error message -->
                                <label for="subscribeEmail"  class="error"></label>
                                            
                                <div class=" input-group">
                                <input type="email" class="form-control" id="subscribeEmail" name="EMAIL" placeholder="Type your email" style="z-index: 1">
                                    <span class=" input-group-btn" style="z-index: 1">
                                        <button type="submit" class="mleft btn btn-success btn-sm text-uppercase">submit</button>
                                    </span>
                                </div><!-- /input-group -->

                                <!-- to showing success messages -->
                                <p class="subscription-success"></p>
                            </form>
                        </div>
                    </div>

                     
                <!-- </div> -->


         <div class="row mt-30">
<?php
include'connection.php';
$date=date('Y-m-d');
$sql="SELECT * FROM events WHERE eventdate >= '$date' ORDER BY eventdate DESC LIMIT 3";
$result2=mysqli_query($conn,$sql);
if(mysqli_num_rows($result2)>0)
{
while($row=mysqli_fetch_assoc($result2))
{
  $eve_id=$row['event_id'];
?>



           
                    <div class="col">
                        <ul  class="latest-blog-list">
                            <li>
                                <div class="date">
                                  <?php
                                 $date= $row['eventdate'];
                                 $timestamp = strtotime($date);
                                 $day = date('d', $timestamp);
                                 $month=date('M Y', $timestamp);
                                 echo $day;
                                  ?>
                                    <!-- 27 -->
                                   <span><b>
                                    <?php 
                                      echo $month;
                                   ?>
                                     
                                   </b></span>
                                </div>
                                <div class="blog-post" >
                                    <h2><?php echo $row['event_name'];?>
                                    <h3 style="font-stretch: condensed;"><?php echo $row['details'];?> 
                                    <a href="#m1"  rel="modal:open" class="btn btn-link btn-sm event-click-button">
                                      <input type="hidden" class= "eid" name="eid" value="<?php echo $row['event_id']; ?>">
                                       click here to register
                                       </a>
                                       </h3>
                                       </h2>

                                    <!-- <h3 style="font-stretch: condensed;"><?php echo $row['details'];?>  <a  href="#m1" rel="modal:open" class="btn btn-link btn-sm" >click here to register</a> </h3> --><hr>

                                   

                                    
                                </div>
                              </li>
                          </ul>
                    </div>
         
                          
                        
                        <!-- </div> -->

                
 <?php
}
?>

                                <div id="m1" class="modal">
                                 <!--  action="eventregsql.php" -->
                                  <form  method="POST" name="reg" class="register-form" >
                                   <center> <h3>Registration form</h3></center>
                                   <div class="row mleft">
                                      <input type="text" id= "username" name="username" class="col-md-4  mt-20" placeholder="Name" >
                                      <input  type="email" id= "mail" name="email" class="col-md-4 mb-20 mleft" placeholder="Email" >
                                      <input type="hidden" id= "eventid" name="eventid" >
                                    </div>
                                  <div class="row mleft">
                                      <input type="text" id= "contactno" name="contactno" class="col-md-4  mt-20" placeholder="Contact No" >
                                      <input type="text" id= "location" name="location" class="col-md-4 mb-20 mleft" placeholder="Current Location" >
                                    </div>
                                    
                                      <div class="form-group row">
                                            <label class="col-lg-3 mleft ">Status<span class="text-danger">:</span>
                                            </label>
                                            <div class="col-lg-8 d-inline">
                                                  <!-- <div class="col-lg-4 displyradio"> -->
                                                    <label class="col-lg-3">
                                              
                                                     <input type="radio" id= "swo1" name="swo" value="Student ">Student
                                                    </label>
                                                    <label class="col-lg-3">
                                                     <input type="radio" id= "swo2" name="swo" value="Working">Working
                                                    </label>
                                                    <label class="col-lg-3">
                                                    <input type="radio"  id= "swo3" name="swo" value="Others">Others
                                                    </label>

                                                                                               
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label class="col-lg-4 col-form-label mleft">select one</a>  <span class="text-danger">:</span>
                                            </label>
                                            <div class="col-lg-6 d-inline">
                                                <label class="css-control css-control-primary css-checkbox" for="wpt">
                                                 <label class="col-lg-6">
                                                     <input type="radio" id= "wpt" name="wpt" value="workshop ">workshop
                                                    </label>
                                                    <label class="col-lg-4">
                                                     <input type="radio" id= "wpt" name="wpt" value="Training">Training
                                                    </label>
                                                    
                                               
                                                  
                                            </div>
                                        </div>

                                      <!-- <input type="" name="" class="mb-30" placeholder="Current Location" > -->
                                     <br>
                                      <a href="#" class="mr-4" type="button" rel="modal:close"><b class="mleft">Close</b></a>
                                    <div class="pull-right">
                                      
                      <button class="btn btn-success btn-sm mright submit-click-button">Submit</button>
                                    </div> 

                                  </form>
  
                                 </div>

<?php
}else
{
  ?>
     
  <div class="row mt-30">
<h1 class="mleft">Events will upload soon!!!!!!!!!</h1>
</div>
 </div>
<?php
}
?>


 <!-- <div  class="aboutsize"></div> -->


                    <!-- </div> -->
                      



                    

            </div><!-- /.container -->
            </section>

        <!-- News Section End -->

         <!--Start Portfolio-->
         <div id="portfolio" class="aboutsize"></div>
        <div  class="grid section-padding">

          <div class="protfolio-title container ">
                <div class="section-title padding-bottom">
                        <h2>GALLERY</h2>
                        <div class="title-border-container">
                            <div class="title-border"></div>
                        </div>
                    </div>
                        <!-- <h1><b>GALLERY</b></h1 -->
                     <!-- </div>        -->

        <label for="pic-1" class="grid-item"><img src="assets/images/calibroz1.jpeg" alt="Gallery Image"></label>
        <label for="pic-2" class="grid-item"><img src="assets/images/calibroz2.jpeg" alt="Gallery Image"></label>
        <label for="pic-1" class="grid-item"><img src="assets/images/calibroz3.jpeg" alt="Gallery Image"></label>
        <label for="pic-1" class="grid-item"><img src="assets/images/calibroz4.jpeg" alt="Gallery Image"></label>
        <label for="pic-1" class="grid-item"><img src="assets/images/calibroz5.jpeg" alt="Gallery Image"></label>
        <label for="pic-1" class="grid-item"><img src="assets/images/calibroz6.jpeg" alt="Gallery Image"></label>


      

      </div>
  </div>
  <section>
       <div id="testimonials" class="aboutsize"></div>
        <div  class="grid section-padding">

          <div class="protfolio-title container ">
                <div class="section-title padding-bottom">
                        <h2>TESTIMONIALS</h2>
                        <div class="title-border-container">
                            <div class="title-border"></div>
                        </div>
                    </div>

                    <div class="container">
    <div class="row">
        <div class="col-md-offset-2 col-md-8">
            <div id="testimonial-slider" class="owl-carousel">
            <div class="testimonial">
                                    <div class="testimonial-content">
                                        <p class="description">
                                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. In dapibus nisi nec rutrum gravida. Nullam ornare sed libero non viverra. Quisque auctor cursus purus. Donec lacinia elementum justo sit amet vulputate. Phasellus varius sapien sed.
                                        </p>
                                    </div>
                                    <div class="testimonial-profile">
                                        <div class="pic">
                                            <img src="assets/images/test1.jpg" alt="hoy">
                                        </div>
                                        <h3 class="title">
                                           Vinaya
                                            <span class="post">Software tester,Atees Infomedia Pvt ltd</span>
                                        </h3>
                                    </div>
                                </div>
                                   <div class="testimonial">
                                    <div class="testimonial-content">
                                        <p class="description">
                                            One of  the best training institute for learning software testing in Kochi.They provides excellent training automation testing(tools) with practical experiences along with the theoretical knowledge. Well experienced and motivating faculties.Instructors are excellent and the training material is very helpful as well. I would strongly recommend Calibroz those who want to build a career in software testing field.
                                        </p>
                                    </div>
                                    <div class="testimonial-profile">
                                        <div class="pic">
                                            <img src="assets/images/test2.jpg" alt="hoy">
                                        </div>
                                        <h3 class="title">
                                            Sujith Pulickamannil
                                            <span class="post">Senior Test Engineer </span>
                                        </h3>
                                    </div>
                                </div>
                                  <div class="testimonial">
                                    <div class="testimonial-content">
                                        <p class="description">
                                           I feel Calibroz offered me the best opportunity for development
                                                of my skills in Software Testing.
                                            I have found that the method of teaching is different from the 
                                            one I am used to. Training under working professional, helps to grab both theory and practical sessions in a better way. 
                                            I would like to recommend "Calibroz" for those who are aiming a career in IT industry.
                                            I had a wonderful experience there . Thank you team Calibroz for Excellent training classes.
                                        </p>
                                    </div>
                                    <div class="testimonial-profile">
                                        <div class="pic">
                                            <img src="assets/images/test3.jpg" alt="hoy">
                                        </div>
                                        <h3 class="title">
                                            Arsha Jose
                                            <span class="post">Auberon Technology Smartcity Kochi</span>
                                        </h3>
                                    </div>
                                </div>
                                <div class="testimonial">
                                    <div class="testimonial-content">
                                        <p class="description">
                                           Excellent classes and a very good trainers. I will most certainly recommend calibroz  to my friends that are interested in software testing. I am really satisfied.Thank you so much!
                                        </p>
                                    </div>
                                    <div class="testimonial-profile">
                                        <div class="pic">
                                            <img src="assets/images/test4.jpg" alt="hoy">
                                        </div>
                                        <h3 class="title">
                                            Sruthi
                                            <span class="post">Fingent global solutions</span>
                                        </h3>
                                    </div>
                                </div>
                                <div class="testimonial">
                                    <div class="testimonial-content">
                                        <p class="description">
                                           A great place to learn your dream technology. 
                                          Training by Dedicated and experienced industry professionals. Class room sessions include real time business scenarios to learn and nurture yourself. Learning environment is superior. 
                                          Overall a better and right place for a tech enthusiast.
                                        </p>
                                    </div>
                                    <div class="testimonial-profile">
                                        <div class="pic">
                                            <img src="assets/images/test5.jpg" alt="hoy">
                                        </div>
                                        <h3 class="title">
                                           Jerin Jacob
                                            <span class="post">TCS , Infopark, Kochi</span>
                                        </h3>
                                    </div>
                                </div>
                                <div class="testimonial">
                                    <div class="testimonial-content">
                                        <p class="description">
                                           I had a great experience at Calibroz. Every aspect of Software testing was taught with practical examples of live projects. So it was very easy to learn and adapt the things in the training. Also I got the opportunity to work on live projects. Thank You Calibroz.
                                        </p>
                                    </div>
                                    <div class="testimonial-profile">
                                        <div class="pic">
                                            <img src="assets/images/test6.jpg" alt="hoy">
                                        </div>
                                        <h3 class="title">
                                           Jyothis Maria
                                            <span class="post">UST Global , infopark, Kochi</span>
                                        </h3>
                                    </div>
                                </div>
                                <div class="testimonial">
                                    <div class="testimonial-content">
                                        <p class="description">
                                           I chose Calibroz because I simply could not find any other institutions that offered all the facilities I needed under one platform. An excellent automation syllabus, real time examples with framework design,phone and online support to students and an awesome atmosphere to learn with. I also love Calibroz because of the infrastructure and the vast experienced faculties. To all the students who doubts where to join , I would say don't waste your time and simply go Calibroz.
                                           Love from Hamburg, Germany 

                                        </p>
                                    </div>
                                    <div class="testimonial-profile">
                                        <div class="pic">
                                            <img src="assets/images/test7.jpg" alt="hoy">
                                        </div>
                                        <h3 class="title">
                                          Arun Dev
                                            <span class="post">Software Engineer,PIT Solutions pvt ltd</span>
                                        </h3>
                                    </div>
                                </div>
                                <div class="testimonial">
                                    <div class="testimonial-content">
                                        <p class="description">
                                               I chose Calibroz because I simply could not find any other institutions that offered all the facilities I needed under one platform. An excellent automation syllabus, real time examples with framework design,phone and online support to students and an awesome atmosphere to learn with. I also love Calibroz because of the infrastructure and the vast experienced faculties. To all the students who doubts where to join , I would say don't waste your time and simply go Calibroz.
                                           Love from Hamburg, Germany
                                        </p>
                                    </div>
                                    <div class="testimonial-profile">
                                        <div class="pic">
                                            <img src="assets/images/test8.jpg" alt="hoy">
                                        </div>
                                        <h3 class="title">
                                            Lipson
                                            <span class="post">Dreamlines GmbH,Germany</span>
                                        </h3>
                                    </div>
                                </div>
                                <div class="testimonial">
                                    <div class="testimonial-content">
                                        <p class="description">
                                            My experience with Calibroz Cyber Campus was amazing. I am immensely thankful to them for providing the training which helped me groom and prepare myself for challenges in IT industry. The Faculty and staff are all dedicated to our success and innovation. The flexible and professional environment in Calibroz Cyber Campus for learning provides opportunity to explore yourself is highly appreciable.
                                        </p>
                                    </div>
                                    <div class="testimonial-profile">
                                        <div class="pic">
                                            <img src="assets/images/test9.jpg" alt="hoy">
                                        </div>
                                        <h3 class="title">
                                           AFSIN 
                                            <span class="post">Gadgeon Smart Systems,SCK</span>
                                        </h3>
                                    </div>
                                </div>
            </div>
        </div>
    </div>
</div>





      </div>
  </div>
  </section>


    <!--End of portfolio-->


       <!-- Contact Section -->
        <section  class="contact-section section-padding">
            <div id="contact" class="aboutsize"></div>

            <div class="paddingx row">
                    <div class="col-md-8 addressandmap white-color">

                            <div class="rows findUs">   
                                
                                <div class="col-md-6">

                                        <h2 class="text-uppercase  center white-color">find us</h2>
                                        <div class="findusSingle">
                                                <i class="fa fa-map-marker mr-5 white-color"></i> 
                                                <span >
                                                    Calibroz Cyber Campus, Marvel Plaza, <br>HMT Rd, Opposite Govt. ITI,  Kalamassery,<br> Kochi, Kerala,India 683104<br>
                                                </span>
                                        </div>   

                                </div>

                                <div class="col-md-6 phone">

                                        <div class="findusSingle">
            
                                                <i class="fa fa-phone mr-1 white-color"></i>
                                               <span>
                                                0484-2544563
                                               </span>
                                       </div>
                                            <div class="findusSingle">
            
                                                <i class="fa fa-whatsapp  mr-1 white-color"></i>
                                               <span>
                                               7356353563
                                               </span>
                                       </div>
                   
                                    <div class="findusSingle">
                                           <i class="fa fa-globe mr-1 white-color"></i>
                                           <span>
                                               www.calibroz.com
                                           </span>
                                    </div>

                                </div>
                                                              
                                   
                                 
                            </div>
                        <div class="Gmap" height="100%">
                                <iframe  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15714.447349316208!2d76.3236492233564!3d10.04885427298516!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b080c2fa26be63b%3A0xcda61e92abdff9e3!2sCalibroz+Cyber+Campus!5e0!3m2!1sen!2sin!4v1562934027011!5m2!1sen!2sin" width="100%" height="100%" frameborder="0" allowfullscreen></iframe>
                        </div>
        
        
                     </div>
                                       
                   

                

                <div class="col-md-4 contactform">
                        <div class="text-center">
                                <h3 class="text-uppercase white-color">Leave a message for any query</h3>
                            </div>
                    <form name="myForm" id="contactForm"  method="POST">
                        
                        <div class="row padding2">
                            <div class="col-md">
                                <div class="form-group">
                                  <label class="white-color" for="name">Name</label>
                                  <input type="text" name="name" class="form-control input" id="name" required>
                                  <p class="required_text" id="demo"></p>
                                </div>
                            </div>
                            
                            <!--hgaajakakaa-->
                            
                            <div class="col-md">
                                <div class="form-group">
                                  <label class="white-color" for="name">Mobile Number</label>
                                  <div class="flex2">

                                    <input type="text" name="number" class="form-control customInput input" id="number" required>
                                  <button id="validate" class="btn validatebtn btn-sm" onclick="myOtp()">validate</button>
                                  </div>
                                  
                                  <p class="required_text" id="demo2"></p>
                                </div>
                            </div>
                            
                            
                            <!--sjsksklsll-->
                            
                           
                            <!--</div>-->
                            <div class="col-md">
                                <div class="form-group">
                                  <label class="white-color" for="name">OTP</label>
                                  <input type="text" name="otp" class="form-control input" id="otp" maxlength="4" required>
                                  <p class="required_text" id="demo3"></p>

                                </div>
                            </div>
                            <div class="col-md">
                                <div class="form-group">
                                  <label class="white-color" for="email">Email</label>
                                  <input type="email" name="email" class="form-control input" id="email" >
                                </div>
                            </div>
                        
                        </div>
                        <div class="col-md">

                        <div class="form-group">
                          <label class="white-color" for="message">Message</label>
                          <textarea name="message" class="form-control" id="message" rows="10" cols="100"></textarea>
                        </div>
                        </div>

                        <button type="submit" name="submit" onclick="myFunction()" class="btn btn-outline-light btn-lg">Send</button>
                    </form> 
                    
                </div>

                    <!-- <div class="text-center"> -->
                    
                <!-- </div> -->
            
        </div>
      
</a>
        <!-- /.container -->
        </section>
        <!-- Contact Section End-->


        <!-- Footer Section -->
        <footer class="footer-section container" >
            <!-- <div class="container"> -->
                <div class="row footerheight">
                    <div class="col-sm-6">
                        ©copyright  <i class="fa fa-love"></i><a href="https://bootstrapthemes.co">Calibroz</a>
                    </div>
                    <div class="col-sm-6 text-right">
                        <ul class="footer-menu list-inline">
                            
                        </ul>
                    </div>
                </div>
            <!-- </div> -->
        </footer>
        <!-- Footer Section End -->


        <!-- Preloader -->
        <div id="preloader">
            <div id="status">
                <div class="status-mes"> <center><img src="assets/images/preloader3.gif"></center></div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- <script src="/assets/back_to_top.js"> </script> -->

        <!-- jQuery -->
        <!-- <script src="assets/js/jquery-2.2.2.min.js"></script> -->
        <script src="assets/js/jquery-3.4.1.min.js"></script>


         <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.easing.min.js"></script>
        <script src="assets/js/smoothscroll.min.js"></script>
        <script src="assets/js/jquery.sticky.js"></script>
        <script src="assets/js/jquery.inview.min.js"></script>
        <script src="assets/js/jquery.countTo.min.js"></script>
        <script src="assets/js/jquery.shuffle.min.js"></script>
        <script src="assets/magnific-popup/jquery.magnific-popup.min.js"></script>
        <script src="assets/js/jquery.BlackAndWhite.min.js"></script>
        <!-- <script src="assets/owl.carousel/owl.carousel.js"></script> -->
        <script src="assets/js/ajaxchimp.js"></script>
        <script src="assets/js/jquery-jvectormap-2.0.3.min.js"></script>
        <script src="assets/js/jquery-jvectormap-world-mill-en.js"></script>
        <script src="assets/js/scripts.js"></script>
        <script src="formvalidation.js"></script>
        <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
        <!-- <script type="text/javascript" src="https://code.jquery.com/jquery-1.12.0.min.js"></script> -->
       


             <!-- Remember to include jQuery :) -->
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.min.js"></script> -->

<!-- jQuery Modal -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script> 

<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-KJ9R6RP"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

<script>
  $(document).ready(function(){
    $(".event-click-button").click(function(){
      var v = $(this).closest("div.blog-post").find("input[name='eid']").val();
      // alert(v);
      $("#eventid").val(v);

    });
  });

</script>
<script>
  $(document).ready(function(){
    $(".submit-click-button").click(function(){
      

       var username = $('#username').val();
       var email = $('#mail').val();
       var contactno = $('#contactno').val();
       var location = $('#location').val();
       // var swo1 = $('#swo1').val();
       // var swo2 = $('#swo2').val();
       // var swo3 = $('#swo3').val();
       var swo= $('input[name="swo"]:checked').val();
       var wpt = $('input[name="wpt"]:checked').val();

       // alert(wpt);
       // alert(swo);

        var xmlhttp = new XMLHttpRequest();
                      xmlhttp.open("GET", "eventregsql.php?username="+username+"&email="+email+"&eventid="+eventid.value+"&contactno="+contactno+"&location="+location+"&swo="+swo+"&wpt="+wpt);
                      xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                      xmlhttp.send();
                      xmlhttp.onreadystatechange = function() 
                                    {
                        if (this.readyState === 4 && this.status === 200)
                         {
                          window.alert(this.responseText);
                      
                        }
                      } 

      
    });
  });
</script>
    </body>
</html>
<?php

?>