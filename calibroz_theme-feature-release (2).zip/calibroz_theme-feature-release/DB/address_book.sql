-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 30, 2019 at 03:54 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `address_book`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE IF NOT EXISTS `attendance` (
  `student_id` varchar(10) NOT NULL,
  `date` date NOT NULL,
  `batch_id` varchar(5) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`student_id`, `date`, `batch_id`, `status`) VALUES
('1', '2019-04-01', '1', 'absent'),
('1', '2019-03-22', '1', 'absent'),
('1', '2019-03-25', '1', 'absent'),
('1', '2019-04-03', '1', 'absent'),
('1', '2018-03-01', '1', 'absent'),
('1', '2019-04-22', '4', 'absent'),
('1', '2019-04-25', '4', 'present'),
('2', '2019-04-25', '4', 'present'),
('1', '2019-04-01', '1', 'absent'),
('1', '2019-03-22', '1', 'absent'),
('1', '2019-03-25', '1', 'absent'),
('1', '2019-04-03', '1', 'absent'),
('1', '2018-03-01', '1', 'absent'),
('1', '2019-04-22', '4', 'absent'),
('1', '2019-04-25', '4', 'present'),
('2', '2019-04-25', '4', 'present');

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

DROP TABLE IF EXISTS `batch`;
CREATE TABLE IF NOT EXISTS `batch` (
  `batch_id` int(5) NOT NULL AUTO_INCREMENT,
  `batch_idgen` varchar(50) NOT NULL,
  `batch_name` varchar(10) NOT NULL,
  `no_of_students` int(2) NOT NULL,
  `start_time` varchar(30) NOT NULL,
  `end_time` varchar(30) NOT NULL,
  `batch_time` varchar(30) DEFAULT NULL,
  `tutor_id` varchar(20) NOT NULL,
  `batch_status` varchar(10) DEFAULT NULL,
  `course_id` varchar(20) NOT NULL,
  PRIMARY KEY (`batch_id`),
  UNIQUE KEY `batch_idgen` (`batch_idgen`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `batch`
--

INSERT INTO `batch` (`batch_id`, `batch_idgen`, `batch_name`, `no_of_students`, `start_time`, `end_time`, `batch_time`, `tutor_id`, `batch_status`, `course_id`) VALUES
(87, 'CB1001', ' java', 30, '9am', '10am', '1hr', 'php', 'on going', 'CC1001'),
(88, 'CB1002', ' java', 30, '9am', '10am', '1hr', 'php', 'on going', 'CC1001'),
(89, 'CB1003', ' php', 30, '9am', '10am', '1hr', 'CT1006', 'on going', 'CC1003'),
(90, 'CB1004', ' java', 30, '9am', '10am', '1hr', 'CT10016', 'on going', 'CC1001'),
(91, 'CB1005', ' php', 30, '9am', '10am', '1hr', 'CT10019', 'on going', 'CC1003'),
(92, 'CB1006', ' java', 30, '9am', '10am', 'Fulltime', 'CT10020', 'on going', 'CC1001'),
(93, 'CB1007', ' php', 30, '9am', '10am', 'Fulltime', 'CT10021', 'on going', 'CC1002'),
(94, 'CB1008', ' Pythoner', 30, '9am', '10am', '', 'CT10019', 'on going', 'CC1005'),
(95, 'CB1009', ' php', 30, '9am', '10am', 'Morning', 'CT1001', 'on going', 'CC1002'),
(96, 'CB10010', ' php', 30, '9am', '10am', 'Morning', 'CT10020', 'on going', 'CC1002');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

DROP TABLE IF EXISTS `book`;
CREATE TABLE IF NOT EXISTS `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) NOT NULL,
  `address` varchar(500) NOT NULL,
  `phone` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`id`, `name`, `address`, `phone`, `email`) VALUES
(18, 'aaaaaaafrgggg', 'tyr', 'erte', 'fyyf@gmial.com'),
(19, 'rtere', 'retr', 'tret', 'tete'),
(21, 'aaaaaa', 'aaaaaa', 'aaaaaaa', 'aaaaaaa'),
(22, 'fdds', 'sfd', 'sfsd', 'sfsd');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
CREATE TABLE IF NOT EXISTS `course` (
  `course_id` int(5) NOT NULL AUTO_INCREMENT,
  `course_idgen` varchar(25) NOT NULL,
  `course_name` varchar(200) NOT NULL,
  `course_duration` varchar(50) NOT NULL,
  `course_fee` varchar(10) NOT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `course_idgen`, `course_name`, `course_duration`, `course_fee`) VALUES
(30, 'CC1001', 'java', '8 months', '20000'),
(34, 'CC1002', 'php', '3 months', '20000'),
(44, 'CC1003', 'php', '3 months', '20000'),
(45, 'CC1004', 'php', '3 months', '20000'),
(46, 'CC1005', 'Pythoner', '3 months', '20000'),
(47, 'CC1006', 'Pythoner', '3 months', '20000'),
(48, 'CC1007', 'android', '8 months', '15,000/-'),
(49, 'CC1008', 'html', '3 months', '15,000/-'),
(50, 'CC1009', 'android', '8 months', '20000'),
(51, 'CC10010', 'php', '3 months', '20000'),
(52, 'CC10011', 'php', '3 months', '15,000/-'),
(53, 'CC10012', '', '', ''),
(54, 'CC10013', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

DROP TABLE IF EXISTS `enquiry`;
CREATE TABLE IF NOT EXISTS `enquiry` (
  `candidate_id` int(3) NOT NULL AUTO_INCREMENT,
  `candidate_name` varchar(100) NOT NULL,
  `candidate_dob` date NOT NULL,
  `candidate_email` varchar(100) NOT NULL,
  `candidate_phone` varchar(15) NOT NULL,
  `candidate_edu_quali` varchar(50) NOT NULL,
  `candidate_tech_quali` text NOT NULL,
  PRIMARY KEY (`candidate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`candidate_id`, `candidate_name`, `candidate_dob`, `candidate_email`, `candidate_phone`, `candidate_edu_quali`, `candidate_tech_quali`) VALUES
(1, 'arya', '1996-11-11', 'dhsjhd@ndv.com', '9633225588', 'fgg', 'jdh'),
(2, 'arya', '1996-11-11', 'dhsjhd@ndv.com', '9633225588', 'fgg', 'jdh');

-- --------------------------------------------------------

--
-- Table structure for table `enquiryform`
--

DROP TABLE IF EXISTS `enquiryform`;
CREATE TABLE IF NOT EXISTS `enquiryform` (
  `Id` int(25) NOT NULL AUTO_INCREMENT,
  `otp` int(20) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Mobileno` varchar(12) NOT NULL,
  `Message` varchar(500) NOT NULL,
  `update_status` varchar(50) NOT NULL,
  `confirm_date` date NOT NULL,
  `followup_date` date NOT NULL,
  `reject_date` date NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiryform`
--

INSERT INTO `enquiryform` (`Id`, `otp`, `Name`, `Email`, `Mobileno`, `Message`, `update_status`, `confirm_date`, `followup_date`, `reject_date`) VALUES
(1, 1234, 'jasna', 'jasna@gmail.com', '98776565', 'qerfghytj', 'confirm', '2019-08-26', '2019-08-23', '2019-08-22'),
(2, 1234, 'kadf', 'mbhjg', '9988776655', ',mkjhjytr', 'reject', '2019-08-22', '2019-08-22', '2019-08-22');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
CREATE TABLE IF NOT EXISTS `events` (
  `event_id` int(25) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(500) NOT NULL,
  `eventdate` date NOT NULL,
  `category` varchar(500) NOT NULL,
  `details` varchar(1000) NOT NULL,
  PRIMARY KEY (`event_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`event_id`, `event_name`, `eventdate`, `category`, `details`) VALUES
(18, 'RPA', '2019-07-29', 'student', 'One day workshop on dsddasuhashucbasuhcbascuhbvcsahcvshcvashucascgvasgcvasugcvsaugcuasgvcuasgcguasvcuiasgciyascyuascyuasvcuyascuyasvcuysacyuaschasyucsa'),
(19, 'two', '2019-08-28', '2', 'two two'),
(20, 'three', '2019-08-27', '3', 'three three'),
(21, 'HTML', '2019-08-16', 'jjhhgft', 'hjutytyrr5e3w2q'),
(22, 'jasna', '2019-09-14', '12', 'three three');

-- --------------------------------------------------------

--
-- Table structure for table `event_enquiry`
--

DROP TABLE IF EXISTS `event_enquiry`;
CREATE TABLE IF NOT EXISTS `event_enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `Mobileno` varchar(35) NOT NULL,
  `location` varchar(500) NOT NULL,
  `swo` varchar(500) NOT NULL,
  `work_training` varchar(500) NOT NULL,
  `dated` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_enquiry`
--

INSERT INTO `event_enquiry` (`id`, `username`, `email`, `Mobileno`, `location`, `swo`, `work_training`, `dated`) VALUES
(31, 'admin', 'hr@prvak.in', '9566546295', 'calicut', 'student ', 'Training', '2019-08-30'),
(32, 'admin', 'jasnahassan29@gmail.com', '9566546295', 'calicut', 'student ', 'Training', '2019-08-30'),
(30, 'jasna', 'hr@prvak.in', '9566546295', 'calicut', 'student ', 'Training', '2019-08-30'),
(29, 'admin', 'jasnahassan29@gmail.com', '9566546295', 'calicut', 'student ', 'work shop', '2019-08-30');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `feedback_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `user_id` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `issue` text,
  `suggestion` text,
  `role` varchar(15) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`feedback_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`feedback_id`, `date`, `user_id`, `type`, `issue`, `suggestion`, `role`, `status`) VALUES
(1, '0000-00-00', 'sru@gmail.com', '', 'issue', 'lack of internet', 'tutor', 'v'),
(2, '0000-00-00', 'sru@gmail.com', '', 'issue', 'lack of internet', 'tutor', 'n'),
(3, '0000-00-00', 'arya@gmail.com', '', NULL, NULL, 'student', 'n'),
(4, '0000-00-00', 'sru@gmail.com', 'issue', 'njkk', 'dhjf', 'tutor', 'n'),
(5, '0000-00-00', 'sru@gmail.com', 'issue', 'njkk', NULL, 'tutor', 'v'),
(6, '0000-00-00', 'sru@gmail.com', 'issue', NULL, NULL, 'tutor', 'v'),
(7, '2019-05-03', 'sru@gmail.com', 'issue', 'network', NULL, 'tutor', 'n'),
(8, '2019-05-10', 'arya@gmail.com', 'issue', 'network connection error', 'kfjdfjsjldfs', 'student', 'n'),
(9, '2019-05-10', 'arya@gmail.com', 'issue', 'network connection error', NULL, 'student', 'n');

-- --------------------------------------------------------

--
-- Table structure for table `leave`
--

DROP TABLE IF EXISTS `leave`;
CREATE TABLE IF NOT EXISTS `leave` (
  `leave_id` int(5) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(200) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `catogory` varchar(30) NOT NULL,
  `reason` text NOT NULL,
  `role` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL,
  `batch_id` int(5) NOT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `leave`
--

INSERT INTO `leave` (`leave_id`, `user_id`, `start_date`, `end_date`, `catogory`, `reason`, `role`, `status`, `batch_id`) VALUES
(1, 'sru@gmail.com', '2012-01-19', '2015-01-19', '', 'fever', 'tutor', 'approved', 0),
(2, 'su@gmail.com', '0000-00-00', '0000-00-00', 'sick leave', 'ff', 'sdgsd', 'approved', 0),
(3, 'su@gmail.com', '0004-00-19', '0004-04-04', 'sick leave', 'ff', 'tutor', 'approved', 0),
(4, 'sru@gmail.com', '0004-00-19', '0004-04-04', 'sick leave', 'ff', 'tutor', 'pending', 0),
(5, 'arya@gmail.com', '2019-05-15', '2019-05-08', 'jjjjj', 'kkkkk', 'student', 'pending', 1),
(6, 'sru@gmail.com', '2019-05-08', '2019-05-08', 'sru@gmail.com', 'sru', 'sru', 'pending', 0);

-- --------------------------------------------------------

--
-- Table structure for table `news_letter`
--

DROP TABLE IF EXISTS `news_letter`;
CREATE TABLE IF NOT EXISTS `news_letter` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `dated` date DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news_letter`
--

INSERT INTO `news_letter` (`Id`, `email`, `dated`) VALUES
(1, 'jasnahassan29@gmail.com', '2019-08-26'),
(2, 'jasnahassan29@gmail.com', '2019-08-26'),
(3, 'fenas@gmail.com', '2019-08-27'),
(4, 'jasnahassan29@gmail.com', '2019-08-27'),
(5, '', '2019-08-27'),
(6, 'jasnahassan29@gmail.com', '2019-08-27'),
(7, '', '2019-08-27'),
(8, '', '2019-08-27'),
(9, 'jasnahassan29@gmail.com', '2019-08-28'),
(10, 'jasnahassan29@gmail.com', '2019-08-28'),
(11, '', '2019-08-29'),
(12, 'jasnahassan29@gmail.com', '2019-08-30');

-- --------------------------------------------------------

--
-- Table structure for table `registraion`
--

DROP TABLE IF EXISTS `registraion`;
CREATE TABLE IF NOT EXISTS `registraion` (
  `Id` int(20) NOT NULL AUTO_INCREMENT,
  `tutor_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobileno` varchar(50) NOT NULL,
  `date_of_joining` varchar(50) NOT NULL,
  `Qualification` varchar(100) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registraion`
--

INSERT INTO `registraion` (`Id`, `tutor_name`, `email`, `mobileno`, `date_of_joining`, `Qualification`) VALUES
(1, 'jasna', 'jasnahassan29@gmail.com', '9566546295', '5/10/2019', 'btech'),
(2, 'jasmin', 'jasnahassan29@gmail.com', '9566546295', '09/10/15', 'angular'),
(3, 'aadhi', 'jasnahassan29@gmail.com', '9566546295', '09/10/15', ''),
(4, 'aadhi', 'jasnahassan29@gmail.com', '9566546295', '09/10/15', 'angular');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

DROP TABLE IF EXISTS `signup`;
CREATE TABLE IF NOT EXISTS `signup` (
  `Id` int(25) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(50) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`Id`, `username`, `password`, `usertype`) VALUES
(1, 'admin', 'admin', '-1');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `student_id` int(10) NOT NULL AUTO_INCREMENT,
  `student_idgen` varchar(50) DEFAULT NULL,
  `student_name` varchar(200) DEFAULT NULL,
  `student_address` text NOT NULL,
  `student_dob` date DEFAULT NULL,
  `student_gender` varchar(10) DEFAULT NULL,
  `student_email` varchar(200) NOT NULL,
  `password` varchar(30) DEFAULT NULL,
  `student_phone` varchar(15) NOT NULL,
  `id_proof` varchar(150) NOT NULL,
  `id_proof_photo` varchar(150) NOT NULL,
  `student_photo` varchar(100) DEFAULT NULL,
  `student_status` varchar(20) DEFAULT NULL,
  `doj` date DEFAULT NULL,
  `batch_id` varchar(5) DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_idgen`, `student_name`, `student_address`, `student_dob`, `student_gender`, `student_email`, `password`, `student_phone`, `id_proof`, `id_proof_photo`, `student_photo`, `student_status`, `doj`, `batch_id`, `status`, `updated_at`, `created_at`) VALUES
(19, 'CS1001', 'jasmin', 'jasvilla', '2019-08-10', 'male', 'jas.@pv', 'CS1001123', '9566546295', 'SSLC book', '2.jpeg', '1.jpeg', 'Fulltime', '2019-08-17', 'ruby', '1', '2019-08-27 18:30:00', '2019-08-27 18:30:00'),
(20, 'CS1002', 'jasmin', 'hj,lk.', '2019-08-17', 'Fulltime', 'jasnahassan29@gmail.com', 'CS1002123', '9566546295', 'Voter id', 'portfolio-5.jpg', 'portfolio-3.jpg', 'Fulltime', '2019-08-10', '', '1', '2019-08-29 18:30:00', '2019-08-29 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `syllabus`
--

DROP TABLE IF EXISTS `syllabus`;
CREATE TABLE IF NOT EXISTS `syllabus` (
  `syllabus_id` int(5) NOT NULL AUTO_INCREMENT,
  `course_id` varchar(5) NOT NULL,
  `syllabus_content` text NOT NULL,
  PRIMARY KEY (`syllabus_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `syllabus`
--

INSERT INTO `syllabus` (`syllabus_id`, `course_id`, `syllabus_content`) VALUES
(1, '2', 'jjkkkjhhhhhh'),
(2, '1', 'kjkjjk'),
(3, '3', ' xc'),
(4, '4', 'x');

-- --------------------------------------------------------

--
-- Table structure for table `topic`
--

DROP TABLE IF EXISTS `topic`;
CREATE TABLE IF NOT EXISTS `topic` (
  `topic_id` int(11) NOT NULL AUTO_INCREMENT,
  `syllabus_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  PRIMARY KEY (`topic_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `topic`
--

INSERT INTO `topic` (`topic_id`, `syllabus_id`, `title`) VALUES
(1, 1, 'Introduction'),
(2, 1, 'Basic Syntax '),
(3, 1, 'Defining variable and constant '),
(4, 1, 'Php Data type operators and expressions'),
(5, 1, 'Capturing Form Data'),
(6, 1, 'Dealing with Multi-value filed '),
(7, 1, 'Generating File uploaded form'),
(8, 1, 'Redirecting a form after submission'),
(9, 1, 'Form designing'),
(10, 1, 'Decisions and loop'),
(11, 1, 'Function'),
(12, 1, 'String'),
(13, 1, 'Array'),
(14, 1, 'Working with file and Directories'),
(15, 1, 'State management'),
(16, 1, 'String matching with regular expression'),
(17, 1, 'Generating Images with PHP'),
(18, 1, 'Database Connectivity with MySql'),
(19, 1, 'Mini Project'),
(20, 2, 'Basics of Android'),
(21, 2, 'UI Widgets'),
(22, 2, 'Activity, Intent & Fragment'),
(23, 2, 'Android Menu'),
(24, 2, 'Layout Manager'),
(25, 2, 'Adaptor'),
(26, 2, 'View'),
(27, 2, 'Android Service'),
(28, 2, 'Data Storage'),
(29, 2, 'SQLite'),
(30, 2, 'Cotent Provider'),
(31, 2, 'Android Notification'),
(32, 2, 'Speech API and Telephony API'),
(33, 2, 'Location API and animation'),
(34, 2, 'Device Connectivity and sensor'),
(35, 2, 'Android P2P Communication'),
(36, 2, 'web services'),
(37, 2, 'mini project'),
(38, 3, 'Introduction'),
(39, 3, 'Conditional Statements'),
(40, 3, 'Looping'),
(41, 3, 'Control Statements'),
(42, 3, 'String Manipulation'),
(43, 3, 'Lists'),
(44, 3, 'Tuple'),
(45, 3, 'Dictionaries'),
(46, 3, 'Functions'),
(47, 3, 'Modules'),
(48, 3, 'Input-Output'),
(49, 3, 'Exception Handling'),
(50, 3, 'OOPs concept'),
(51, 3, 'Regular expressions'),
(52, 3, 'CGI'),
(53, 3, 'Database'),
(54, 3, 'Networking'),
(55, 3, 'Multithreading'),
(56, 3, 'GUI Programming');

-- --------------------------------------------------------

--
-- Table structure for table `topic_status`
--

DROP TABLE IF EXISTS `topic_status`;
CREATE TABLE IF NOT EXISTS `topic_status` (
  `syllabus_id` int(11) NOT NULL,
  `topic_id` int(5) NOT NULL,
  `tutor_id` varchar(20) NOT NULL,
  `batch_id` int(5) NOT NULL,
  `status` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `topic_status`
--

INSERT INTO `topic_status` (`syllabus_id`, `topic_id`, `tutor_id`, `batch_id`, `status`) VALUES
(1, 1, 'CLBZTR002', 4, '9'),
(1, 2, 'CLBZTR002', 4, '10'),
(1, 3, 'CLBZTR002', 4, '0'),
(1, 4, 'CLBZTR002', 4, '0'),
(1, 5, 'CLBZTR002', 4, '0'),
(1, 6, 'CLBZTR002', 4, '0'),
(1, 7, 'CLBZTR002', 4, '0'),
(1, 8, 'CLBZTR002', 4, '0'),
(1, 9, 'CLBZTR002', 4, '0'),
(1, 10, 'CLBZTR002', 4, '0'),
(1, 11, 'CLBZTR002', 4, '0'),
(1, 12, 'CLBZTR002', 4, '0'),
(1, 13, 'CLBZTR002', 4, '0'),
(1, 14, 'CLBZTR002', 4, '0'),
(1, 15, 'CLBZTR002', 4, '0'),
(1, 16, 'CLBZTR002', 4, '0'),
(1, 17, 'CLBZTR002', 4, '0'),
(1, 18, 'CLBZTR002', 4, '0'),
(1, 19, 'CLBZTR002', 4, '0'),
(1, 1, 'CLBZTR002', 5, '0'),
(1, 2, 'CLBZTR002', 5, '0'),
(1, 3, 'CLBZTR002', 5, '0'),
(1, 4, 'CLBZTR002', 5, '0'),
(1, 5, 'CLBZTR002', 5, '0'),
(1, 6, 'CLBZTR002', 5, '0'),
(1, 7, 'CLBZTR002', 5, '0'),
(1, 8, 'CLBZTR002', 5, '0'),
(1, 9, 'CLBZTR002', 5, '0'),
(1, 10, 'CLBZTR002', 5, '0'),
(1, 11, 'CLBZTR002', 5, '0'),
(1, 12, 'CLBZTR002', 5, '0'),
(1, 13, 'CLBZTR002', 5, '0'),
(1, 14, 'CLBZTR002', 5, '0'),
(1, 15, 'CLBZTR002', 5, '0'),
(1, 16, 'CLBZTR002', 5, '0'),
(1, 17, 'CLBZTR002', 5, '0'),
(1, 18, 'CLBZTR002', 5, '0'),
(1, 19, 'CLBZTR002', 5, '0'),
(2, 20, 'CLBZTR002', 6, '0'),
(2, 21, 'CLBZTR002', 6, '0'),
(2, 22, 'CLBZTR002', 6, '0'),
(2, 23, 'CLBZTR002', 6, '0'),
(2, 24, 'CLBZTR002', 6, '0'),
(2, 25, 'CLBZTR002', 6, '0'),
(2, 26, 'CLBZTR002', 6, '0'),
(2, 27, 'CLBZTR002', 6, '0'),
(2, 28, 'CLBZTR002', 6, '0'),
(2, 29, 'CLBZTR002', 6, '0'),
(2, 30, 'CLBZTR002', 6, '0'),
(2, 31, 'CLBZTR002', 6, '0'),
(2, 32, 'CLBZTR002', 6, '0'),
(2, 33, 'CLBZTR002', 6, '0'),
(2, 34, 'CLBZTR002', 6, '0'),
(2, 35, 'CLBZTR002', 6, '0'),
(2, 36, 'CLBZTR002', 6, '0'),
(2, 37, 'CLBZTR002', 6, '0'),
(3, 2, 'CLBZTR002', 9, '9'),
(1, 1, 'CLBZTR002', 4, '9'),
(1, 2, 'CLBZTR002', 4, '10'),
(1, 3, 'CLBZTR002', 4, '0'),
(1, 4, 'CLBZTR002', 4, '0'),
(1, 5, 'CLBZTR002', 4, '0'),
(1, 6, 'CLBZTR002', 4, '0'),
(1, 7, 'CLBZTR002', 4, '0'),
(1, 8, 'CLBZTR002', 4, '0'),
(1, 9, 'CLBZTR002', 4, '0'),
(1, 10, 'CLBZTR002', 4, '0'),
(1, 11, 'CLBZTR002', 4, '0'),
(1, 12, 'CLBZTR002', 4, '0'),
(1, 13, 'CLBZTR002', 4, '0'),
(1, 14, 'CLBZTR002', 4, '0'),
(1, 15, 'CLBZTR002', 4, '0'),
(1, 16, 'CLBZTR002', 4, '0'),
(1, 17, 'CLBZTR002', 4, '0'),
(1, 18, 'CLBZTR002', 4, '0'),
(1, 19, 'CLBZTR002', 4, '0'),
(1, 1, 'CLBZTR002', 5, '0'),
(1, 2, 'CLBZTR002', 5, '0'),
(1, 3, 'CLBZTR002', 5, '0'),
(1, 4, 'CLBZTR002', 5, '0'),
(1, 5, 'CLBZTR002', 5, '0'),
(1, 6, 'CLBZTR002', 5, '0'),
(1, 7, 'CLBZTR002', 5, '0'),
(1, 8, 'CLBZTR002', 5, '0'),
(1, 9, 'CLBZTR002', 5, '0'),
(1, 10, 'CLBZTR002', 5, '0'),
(1, 11, 'CLBZTR002', 5, '0'),
(1, 12, 'CLBZTR002', 5, '0'),
(1, 13, 'CLBZTR002', 5, '0'),
(1, 14, 'CLBZTR002', 5, '0'),
(1, 15, 'CLBZTR002', 5, '0'),
(1, 16, 'CLBZTR002', 5, '0'),
(1, 17, 'CLBZTR002', 5, '0'),
(1, 18, 'CLBZTR002', 5, '0'),
(1, 19, 'CLBZTR002', 5, '0'),
(2, 20, 'CLBZTR002', 6, '0'),
(2, 21, 'CLBZTR002', 6, '0'),
(2, 22, 'CLBZTR002', 6, '0'),
(2, 23, 'CLBZTR002', 6, '0'),
(2, 24, 'CLBZTR002', 6, '0'),
(2, 25, 'CLBZTR002', 6, '0'),
(2, 26, 'CLBZTR002', 6, '0'),
(2, 27, 'CLBZTR002', 6, '0'),
(2, 28, 'CLBZTR002', 6, '0'),
(2, 29, 'CLBZTR002', 6, '0'),
(2, 30, 'CLBZTR002', 6, '0'),
(2, 31, 'CLBZTR002', 6, '0'),
(2, 32, 'CLBZTR002', 6, '0'),
(2, 33, 'CLBZTR002', 6, '0'),
(2, 34, 'CLBZTR002', 6, '0'),
(2, 35, 'CLBZTR002', 6, '0'),
(2, 36, 'CLBZTR002', 6, '0'),
(2, 37, 'CLBZTR002', 6, '0'),
(3, 2, 'CLBZTR002', 9, '9');

-- --------------------------------------------------------

--
-- Table structure for table `tutor`
--

DROP TABLE IF EXISTS `tutor`;
CREATE TABLE IF NOT EXISTS `tutor` (
  `tutor_id` int(5) NOT NULL AUTO_INCREMENT,
  `tutor_idgen` varchar(50) NOT NULL,
  `tutor_name` varchar(200) NOT NULL,
  `tutor_email` varchar(200) NOT NULL,
  `password` varchar(50) NOT NULL,
  `joindate` date NOT NULL,
  `tutor_image` varchar(100) NOT NULL,
  `work_professional` varchar(100) NOT NULL,
  `availability` varchar(100) NOT NULL,
  `id_proof` varchar(100) NOT NULL,
  `id_image` varchar(50) NOT NULL,
  `tutor_phone` varchar(15) NOT NULL,
  `tutor_edu_quali` varchar(100) NOT NULL,
  `tutor_experience` varchar(20) NOT NULL,
  `doj` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`tutor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tutor`
--

INSERT INTO `tutor` (`tutor_id`, `tutor_idgen`, `tutor_name`, `tutor_email`, `password`, `joindate`, `tutor_image`, `work_professional`, `availability`, `id_proof`, `id_image`, `tutor_phone`, `tutor_edu_quali`, `tutor_experience`, `doj`, `status`) VALUES
(17, 'CT1001', 'jas', 'jas@gmail.com', 'jhjgfd', '3111-02-10', 'no', 'no', 'Fulltime', 'Voter id', '', '9566546295', '', 'adda', '1234-03-12', 1),
(18, 'CT1002', 'jasmin', 'ja@gmail.com', 'jasna', '1996-12-10', 'yes', 'yes', 'Morning', 'SSLC book', '', '9566546295', 'DEGREE', 'adda', '2001-12-10', 0),
(19, 'CT1003', 'jasmin', 'ja9@gmail.com', 'jjggf', '1999-02-10', 'no', 'no', 'Fulltime', 'SSLC book', '', '9566546295', 'BTECH', 'adda', '1990-05-10', 1),
(20, 'CT1004', 'jASNAHASSAN', 'ja29@gmail.com', 'mnhggf', '1999-02-10', 'yes', 'yes', 'Fulltime', 'Voter id', '', '9566546295', '', 'adda', '3000-02-10', 1),
(21, 'CT1005', 'test', 'test@gmail.com', 'test123', '1992-10-10', 'yes', 'yes', 'Fulltime', 'Voter id', '', '9874563214', 'MSC', '1 year', '2019-03-10', 1),
(22, 'CT1006', 'jasmin', 'j29@gmail.com', 'gnhjgfvfg', '1219-12-12', 'yes', 'yes', 'Fulltime', 'Voter id', '', '9566546295', '', 'adda', '3344-03-12', 0),
(23, 'CT1007', 'jasmin', 'j9@gmail.com', '', '1233-04-12', 'yes', 'yes', 'Fulltime', '', '', '9566546295', '', 'adda', '1222-11-12', 1),
(24, 'CT1008', 'test', 'test@gmail.com', 'test123', '1993-01-11', 'yes', 'yes', 'Sunday', 'Pancard', '', '9874563214', 'BCA', '1 year', '2018-02-10', 1),
(25, 'CT1009', 'jasmin', 'jas.@pv', 'JGFNJH', '2202-12-12', 'yes', 'yes', 'Fulltime', 'Voter id', '', '9566546295', 'BSC', 'NO', '2005-12-12', 1),
(26, 'CT10010', 'jASNAHASSAN', 'j9@gmail.com', '1234567890', '2019-08-02', 'yes', 'yes', '', 'SSLC book', '', '9566546295', '', 'NO', '2019-08-02', 1),
(27, 'CT10011', 'jasmin', 'j29@gmail.com', '12344556', '2019-08-10', 'yes', 'yes', 'Saturday', 'Voter id', '', '9566546295', '', 'NO', '2019-08-24', 1),
(28, 'CT10012', 'jasmin', 'ja29@gmail.com', 'hdfdfd', '2209-12-10', 'yes', 'yes', 'Fulltime', 'SSLC book', '', '9566546295', '', 'adda', '2019-08-30', 1),
(29, 'CT10013', 'jasmin', 'jasnahassan29@gmail.com', '12345678', '2019-08-10', '3.jpg', 'no', 'Fulltime', 'SSLC book', '', '9566546295', 'MCA', '', '2019-08-04', 1),
(30, 'CT10014', 'jasmin', 'jas.@pv', '123456', '2019-08-03', '7.jpg', 'yes', 'Evening', 'Driving licence', '', '9566546295', 'BCA', 'NO', '2019-08-03', 1),
(31, 'CT10015', 'jasminQ', 'j29@gmail.com', '12345678', '2019-08-22', '1.jpg', 'no', 'Morning', 'Driving licence', '', '9566546295', 'BTECH', 'NO', '2019-08-25', 1),
(32, 'CT10016', 'jasmin', 'jas.@pv', '', '1111-11-11', 'slider1 (1).jpg', 'no', 'Morning', 'Voter id', 'PinClipart.com_advocate-clipart_13055.png', '9566546295', 'BCA', 'adda', '1111-11-11', 1),
(33, 'CT10017', 'jasmin', 'jas.@pv', 'kjhjtyft', '2019-08-17', 'cc_iStock-618761378_16x9.jpg', 'no', 'Fulltime', 'Voter id', 'oilbg.jpeg', '9566546295', 'MSC', 'adda', '2019-08-25', 1),
(34, 'CT10018', 'jasmin', 'jas.@pv', '', '2019-08-24', 'php.png', 'yes', 'Morning', 'SSLC book', 'map.PNG', '9566546295', 'MSC', 'adda', '2019-08-25', 1),
(35, 'CT10019', 'jasmin', 'jas.@pv', 'jhgytftrd', '2019-08-18', 'team-2.jpg', 'yes', '', 'Voter id', 'team-4.jpg', '9566546295', 'BCA', 'adda', '2019-08-04', 1),
(36, 'CT10020', 'jasmin', 'jas.@pv', 'jgydds', '2019-08-18', 'course01.jpg', 'no', 'Fulltime', 'Voter id', 'mentor.jpg', '9566546295', 'BTECH', 'adda', '2019-08-18', 1),
(37, 'CT10021', 'jASNAHASSAN', 'jasnahassan29@gmail.com', '', '2019-08-28', 'bg.png', 'no', '', 'SSLC book', 'dashboardhome.PNG', '9566546295', 'BCA', 'adda', '2019-08-28', 1),
(38, 'CT10022', 'jasmin', 'jasnahassan29@gmail.com', '', '2019-08-17', '2.jpeg', '', 'Fulltime', 'Voter id', '3 (1).jpeg', '9566546295', '', '', '2019-08-18', 1),
(39, 'CT10023', 'jasmin', 'jasnahassan29@gmail.com', 'hjkkjm', '2019-08-24', '4 (1).jpeg', 'no', '', 'Voter id', '2 (1).jpeg', '9566546295', 'BSC', 'adda', '2019-08-25', 1),
(40, 'CT10024', 'jasmin', 'jas.@pv', 'xfghjkjlk', '2019-08-23', '1 (1).jpeg', 'yes', '', 'Voter id', '220px-Virtual-Fixtures-USAF-AR.jpg', '9566546295', 'BCA', 'NO', '2019-08-17', 1),
(41, 'CT10025', 'jasmin', 'jasnahassan29@gmail.com', 'jasna', '2019-08-31', '2 (1).jpeg', 'yes', 'Fulltime', 'Voter id', '6.jpeg', '9566546295', 'BSC', 'NO', '2019-08-24', 1),
(42, 'CT10026', 'jasmin', 'jas.@pv', '', '2019-08-17', 'portfolio-1.jpg', '', 'Fulltime', 'SSLC book', 'dashboardhome.PNG', '9566546295', 'BCA', 'NO', '2019-08-15', 1),
(43, 'CT10027', 'jasmin', 'jas.@pv', 'hggfdfdd', '2019-08-16', 'portfolio-7.jpg', 'Fulltime', 'Fulltime', 'Voter id', 'portfolio-8.jpg', '9566546295', 'BCA', 'NO', '2019-08-25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_login`
--

DROP TABLE IF EXISTS `user_login`;
CREATE TABLE IF NOT EXISTS `user_login` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(200) NOT NULL,
  `password` varchar(20) NOT NULL,
  `role` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_login`
--

INSERT INTO `user_login` (`login_id`, `user_id`, `password`, `role`, `status`) VALUES
(25, 'jasnahassan29@gmail.com', 'CS1002123', 'student', 'active'),
(26, 'jas.@pv', 'hggfdfdd', 'tutor', 'active');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
