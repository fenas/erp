<?php
include 'connection.php';
$Name = $_GET['name'];
$otp = $_GET['otp'];
$Email = $_GET['email'];
$Mobileno = $_GET['number'];
$Message=$_GET['message'];
$sql="INSERT INTO enquiryform(otp,Name,Email,Mobileno,Message)VALUES ('$otp','$Name','$Email','$Mobileno','$Message')";
$result=mysqli_query($conn,$sql);
if(mysqli_affected_rows($conn)>0)
{
        echo "ok";
}
else
{
   
        echo "failed";
}

?>